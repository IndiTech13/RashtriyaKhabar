<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';

$pdo = db();

$total = (int)$pdo->query("SELECT COUNT(*) FROM posts WHERE status='published'")->fetchColumn();

$closingSoon = (int)$pdo->query(
    "SELECT COUNT(*) FROM posts WHERE status='published' AND last_date IS NOT NULL
     AND last_date >= CURDATE() AND last_date <= DATE_ADD(CURDATE(), INTERVAL 3 DAY)"
)->fetchColumn();

$thisWeek = (int)$pdo->query(
    "SELECT COUNT(*) FROM posts WHERE status='published' AND published_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
)->fetchColumn();

json_out([
    'ok' => true,
    'total' => $total,
    'closing_soon' => $closingSoon,
    'this_week' => $thisWeek,
]);
