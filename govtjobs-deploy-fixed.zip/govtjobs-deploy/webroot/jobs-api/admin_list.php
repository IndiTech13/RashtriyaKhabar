<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';
require_login_api();

$stmt = db()->query('SELECT id, slug, title, status, views, last_date, updated_at, published_at, source_name
                      FROM posts ORDER BY updated_at DESC');
$rows = $stmt->fetchAll();

$posts = array_map(function ($r) {
    return [
        'id'           => (int)$r['id'],
        'slug'         => $r['slug'],
        'title'        => $r['title'],
        'status'       => $r['status'],
        'views'        => (int)$r['views'],
        'last_date'    => $r['last_date'],
        'updated_at'   => $r['updated_at'],
        'published_at' => $r['published_at'],
        'source_name'  => $r['source_name'],
    ];
}, $rows);

json_out(['ok' => true, 'posts' => $posts]);
