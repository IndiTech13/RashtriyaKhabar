<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';
require_login_api();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'Method not allowed.'], 405);
}

$id = (int)($_POST['id'] ?? 0);
if (!$id) json_out(['ok' => false, 'error' => 'Missing post id.'], 400);

$pdo = db();
$stmt = $pdo->prepare('SELECT thumbnail FROM posts WHERE id = ?');
$stmt->execute([$id]);
$row = $stmt->fetch();
if (!$row) json_out(['ok' => false, 'error' => 'Post not found.'], 404);

$pdo->prepare('DELETE FROM posts WHERE id = ?')->execute([$id]);
if ($row['thumbnail']) @unlink(UPLOAD_DIR . '/' . $row['thumbnail']);

json_out(['ok' => true]);
