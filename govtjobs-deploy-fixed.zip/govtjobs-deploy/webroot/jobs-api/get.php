<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';
require_login_api();

$id = (int)($_GET['id'] ?? 0);
if (!$id) json_out(['ok' => false, 'error' => 'Missing post id.'], 400);

$stmt = db()->prepare('SELECT * FROM posts WHERE id = ?');
$stmt->execute([$id]);
$post = $stmt->fetch();
if (!$post) json_out(['ok' => false, 'error' => 'Post not found.'], 404);

$post['id'] = (int)$post['id'];
$post['thumbnail_url'] = $post['thumbnail'] ? UPLOAD_URL . '/' . $post['thumbnail'] : null;
$post['extra_links'] = parse_extra_links($post['extra_links']);

json_out(['ok' => true, 'post' => $post]);
