<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';

$_SESSION = [];
session_destroy();

json_out(['ok' => true]);
