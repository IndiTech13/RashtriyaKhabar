<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';

$q       = trim($_GET['q'] ?? '');
$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 9;
$offset  = ($page - 1) * $perPage;

$where  = ['status = "published"'];
$params = [];

if ($q !== '') {
    $where[] = '(title LIKE ? OR org_name LIKE ? OR excerpt LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like);
}
$whereSql = implode(' AND ', $where);

$pdo = db();

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM posts WHERE $whereSql");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();

$sql = "SELECT id, slug, title, org_name, excerpt, body, thumbnail,
               start_date, last_date, exam_date, published_at
        FROM posts
        WHERE $whereSql
        ORDER BY published_at DESC
        LIMIT $perPage OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$today = new DateTime('today');
$posts = array_map(function ($r) use ($today) {
    $excerpt = $r['excerpt'];
    if (!$excerpt) {
        $plain = trim(strip_tags($r['body']));
        $excerpt = mb_substr($plain, 0, 160) . (mb_strlen($plain) > 160 ? '…' : '');
    }
    $daysLeft = null;
    if ($r['last_date']) {
        $diff = $today->diff(new DateTime($r['last_date']));
        $daysLeft = $diff->invert ? -1 * (int)$diff->days : (int)$diff->days;
    }
    return [
        'id'           => (int)$r['id'],
        'slug'         => $r['slug'],
        'title'        => $r['title'],
        'org_name'     => $r['org_name'],
        'excerpt'      => $excerpt,
        'thumbnail'    => $r['thumbnail'] ? UPLOAD_URL . '/' . $r['thumbnail'] : null,
        'start_date'   => $r['start_date'],
        'last_date'    => $r['last_date'],
        'exam_date'    => $r['exam_date'],
        'days_left'    => $daysLeft,
        'published_at' => $r['published_at'],
    ];
}, $rows);

json_out([
    'ok'          => true,
    'posts'       => $posts,
    'page'        => $page,
    'per_page'    => $perPage,
    'total'       => $total,
    'total_pages' => (int)ceil($total / $perPage),
]);
