<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';
require_login_api();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'Method not allowed.'], 405);
}

$id       = isset($_POST['id']) && $_POST['id'] !== '' ? (int)$_POST['id'] : null;
$title    = trim($_POST['title'] ?? '');
$orgName  = trim($_POST['org_name'] ?? '');
$excerpt  = trim($_POST['excerpt'] ?? '');
$body     = $_POST['body'] ?? '';
$official = trim($_POST['official_link'] ?? '');
$apply    = trim($_POST['apply_link'] ?? '');
$startD   = $_POST['start_date'] ?? '';
$lastD    = $_POST['last_date'] ?? '';
$examD    = $_POST['exam_date'] ?? '';
$status   = ($_POST['status'] ?? 'draft') === 'published' ? 'published' : 'draft';
$extraLabels = $_POST['extra_link_label'] ?? [];
$extraUrls   = $_POST['extra_link_url'] ?? [];

// ---- Validation ----
$errors = [];
if ($title === '' || mb_strlen($title) > 300) $errors[] = 'Title is required (max 300 characters).';
if (trim(strip_tags($body)) === '') $errors[] = 'Post content cannot be empty.';
foreach (['official_link' => $official, 'apply_link' => $apply] as $label => $url) {
    if ($url !== '' && !filter_var($url, FILTER_VALIDATE_URL)) {
        $errors[] = "That doesn't look like a valid $label URL.";
    }
}
foreach (['start_date' => $startD, 'last_date' => $lastD, 'exam_date' => $examD] as $label => $d) {
    if ($d !== '' && !DateTime::createFromFormat('Y-m-d', $d)) $errors[] = "Invalid $label.";
}
if ($errors) json_out(['ok' => false, 'error' => implode(' ', $errors)], 400);

$body = clean_body_html($body);
$extraLinksJson = build_extra_links_json(is_array($extraLabels) ? $extraLabels : [], is_array($extraUrls) ? $extraUrls : []);

$pdo = db();
$existing = null;
if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM posts WHERE id = ?');
    $stmt->execute([$id]);
    $existing = $stmt->fetch();
    if (!$existing) json_out(['ok' => false, 'error' => 'Post not found.'], 404);
}

// ---- Thumbnail upload (optional) ----
$thumbFilename = $existing['thumbnail'] ?? null;
if (!empty($_POST['remove_thumbnail'])) {
    if ($thumbFilename) @unlink(UPLOAD_DIR . '/' . $thumbFilename);
    $thumbFilename = null;
}
if (!empty($_FILES['thumbnail']['tmp_name']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
    $tmp = $_FILES['thumbnail']['tmp_name'];
    $info = @getimagesize($tmp);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!$info || !isset($allowed[$info['mime']])) {
        json_out(['ok' => false, 'error' => 'Thumbnail must be a JPG, PNG, or WEBP image.'], 400);
    }
    if ($_FILES['thumbnail']['size'] > 4 * 1024 * 1024) {
        json_out(['ok' => false, 'error' => 'Thumbnail must be under 4MB.'], 400);
    }
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
    $newName = bin2hex(random_bytes(12)) . '.' . $allowed[$info['mime']];
    if (!move_uploaded_file($tmp, UPLOAD_DIR . '/' . $newName)) {
        json_out(['ok' => false, 'error' => 'Could not save the uploaded image.'], 500);
    }
    if ($thumbFilename) @unlink(UPLOAD_DIR . '/' . $thumbFilename);
    $thumbFilename = $newName;
}

$publishedAt = $existing['published_at'] ?? null;
if ($status === 'published' && !$publishedAt) {
    $publishedAt = date('Y-m-d H:i:s'); // first time going live
}

if ($existing) {
    $slug = ($title !== $existing['title']) ? make_slug($title, $id) : $existing['slug'];
    $sql = 'UPDATE posts SET slug=?, title=?, org_name=?, excerpt=?, body=?, thumbnail=?,
            official_link=?, apply_link=?, extra_links=?, start_date=?, last_date=?, exam_date=?, status=?, published_at=?
            WHERE id=?';
    $pdo->prepare($sql)->execute([
        $slug, $title, $orgName ?: null, $excerpt ?: null, $body, $thumbFilename,
        $official ?: null, $apply ?: null, $extraLinksJson, $startD ?: null, $lastD ?: null, $examD ?: null,
        $status, $publishedAt, $id,
    ]);
} else {
    $slug = make_slug($title);
    $sql = 'INSERT INTO posts (slug, title, org_name, excerpt, body, thumbnail,
            official_link, apply_link, extra_links, start_date, last_date, exam_date, status, published_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    $pdo->prepare($sql)->execute([
        $slug, $title, $orgName ?: null, $excerpt ?: null, $body, $thumbFilename,
        $official ?: null, $apply ?: null, $extraLinksJson, $startD ?: null, $lastD ?: null, $examD ?: null,
        $status, $publishedAt,
    ]);
    $id = (int)$pdo->lastInsertId();
}

json_out(['ok' => true, 'id' => $id, 'slug' => $slug]);
