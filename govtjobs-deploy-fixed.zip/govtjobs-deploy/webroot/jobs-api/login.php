<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'Method not allowed.'], 405);
}

$username = trim($_POST['username'] ?? '');
$password = (string)($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    json_out(['ok' => false, 'error' => 'Username and password are required.'], 400);
}

// Basic throttle: max 8 attempts per 5 minutes per session, to slow down guessing.
$_SESSION['login_attempts'] = $_SESSION['login_attempts'] ?? [];
$_SESSION['login_attempts'] = array_filter($_SESSION['login_attempts'], fn($t) => $t > time() - 300);
if (count($_SESSION['login_attempts']) >= 8) {
    json_out(['ok' => false, 'error' => 'Too many attempts. Wait a few minutes and try again.'], 429);
}

$stmt = db()->prepare('SELECT id, username, password_hash, display_name FROM admin_users WHERE username = ?');
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    $_SESSION['login_attempts'][] = time();
    json_out(['ok' => false, 'error' => 'Incorrect username or password.'], 401);
}

session_regenerate_id(true);
$_SESSION['admin_id']       = $user['id'];
$_SESSION['admin_username'] = $user['username'];
$_SESSION['admin_name']     = $user['display_name'] ?: $user['username'];
unset($_SESSION['login_attempts']);

json_out(['ok' => true, 'name' => $_SESSION['admin_name']]);
