<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';
$loggedIn = !empty($_SESSION['admin_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Panel — Govt Jobs · Rashtriya Khabar</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%230B2545'/%3E%3Ctext x='32' y='42' text-anchor='middle' font-size='30'%3E%F0%9F%8F%9B%EF%B8%8F%3C/text%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Domine:wght@600;700&family=Hind:wght@400;500;600&family=Work+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root{
    --paper:#FFFFFF; --paper-off:#FAF8F2; --ink:#18130F; --ink-soft:#544C42; --ink-faint:#8A8177;
    --navy:#0B2545; --navy-deep:#081A31; --saffron:#E8710A; --maroon:#A61B29; --green:#134D2C; --gold:#C99A2E;
    --rule:#E6E0D2; --rule-strong:#D8CFBB;
  }
  *{margin:0;padding:0;box-sizing:border-box;}
  body{background:var(--paper-off);color:var(--ink);font-family:'Hind',sans-serif;line-height:1.5;}
  a{color:inherit;}
  button,input,select,textarea{font:inherit;}
  img{max-width:100%;display:block;}

  /* ---------- Login screen ---------- */
  .login-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
  .login-card{background:#fff;border:1px solid var(--rule);border-radius:14px;padding:40px 36px;width:100%;max-width:380px;box-shadow:0 20px 50px rgba(11,37,69,.10);}
  .login-card .mark{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg,#E50914,#0B2545);display:flex;align-items:center;justify-content:center;font-size:20px;margin-bottom:18px;}
  .login-card h1{font-family:'Domine',serif;font-size:22px;color:var(--navy);margin-bottom:6px;}
  .login-card p.sub{font-size:13.5px;color:var(--ink-faint);margin-bottom:26px;}
  .field{margin-bottom:16px;}
  .field label{display:block;font-family:'Work Sans',sans-serif;font-size:12px;font-weight:600;color:var(--ink-soft);margin-bottom:6px;}
  .field input,.field select,.field textarea{width:100%;padding:11px 13px;border:1px solid var(--rule-strong);border-radius:7px;background:#fff;font-size:14.5px;transition:border-color .2s,box-shadow .2s;}
  .field input:focus,.field select:focus,.field textarea:focus{outline:none;border-color:var(--navy);box-shadow:0 0 0 3px rgba(11,37,69,.10);}
  .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;font-family:'Work Sans',sans-serif;font-weight:700;font-size:13.5px;padding:12px 20px;border-radius:7px;border:none;cursor:pointer;transition:.2s ease;}
  .btn-navy{background:var(--navy);color:#fff;}
  .btn-navy:hover{background:var(--saffron);}
  .btn-navy:disabled{opacity:.6;cursor:default;}
  .btn-block{width:100%;}
  .error-msg{background:#FDE8E8;color:var(--maroon);font-size:13px;padding:10px 13px;border-radius:7px;margin-bottom:16px;display:none;}
  .error-msg.show{display:block;}

  /* ---------- Dashboard shell ---------- */
  .app{display:none;min-height:100vh;flex-direction:column;}
  .app.show{display:flex;}
  .topbar{background:var(--navy-deep);color:#fff;padding:14px 0;}
  .topbar-inner{max-width:1180px;margin:0 auto;padding:0 24px;display:flex;align-items:center;justify-content:space-between;}
  .topbar-brand{font-family:'Domine',serif;font-weight:700;font-size:17px;display:flex;align-items:center;gap:9px;}
  .topbar-brand .tag{background:var(--saffron);font-family:'Work Sans',sans-serif;font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;letter-spacing:.06em;}
  .topbar-right{display:flex;align-items:center;gap:16px;font-family:'Work Sans',sans-serif;font-size:13px;color:#B9C5D6;}
  .topbar-right button{background:none;border:1px solid rgba(255,255,255,.25);color:#fff;padding:7px 14px;border-radius:6px;cursor:pointer;font-size:12.5px;}
  .topbar-right button:hover{border-color:var(--saffron);color:var(--saffron);}

  .main{max-width:1180px;margin:0 auto;padding:32px 24px 70px;width:100%;flex:1;}
  .view{display:none;}
  .view.show{display:block;}

  /* dashboard view */
  .dash-head{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:14px;margin-bottom:22px;}
  .dash-head h2{font-family:'Domine',serif;font-size:24px;color:var(--navy);}
  .dash-tools{display:flex;gap:10px;flex-wrap:wrap;}
  .dash-tools select,.dash-tools input{padding:9px 12px;border:1px solid var(--rule-strong);border-radius:7px;font-size:13.5px;background:#fff;}
  .table-wrap{background:#fff;border:1px solid var(--rule);border-radius:12px;overflow:hidden;}
  table{width:100%;border-collapse:collapse;}
  thead th{text-align:left;font-family:'Work Sans',sans-serif;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-faint);background:var(--paper-off);padding:12px 16px;border-bottom:1px solid var(--rule);}
  tbody td{padding:14px 16px;border-bottom:1px solid var(--rule);font-size:14px;vertical-align:middle;}
  tbody tr:last-child td{border-bottom:none;}
  tbody tr:hover{background:#FAFAF7;}
  .status-pill{font-family:'Work Sans',sans-serif;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;}
  .status-pill.published{background:#E8F5EC;color:var(--green);}
  .status-pill.draft{background:#F0ECE1;color:var(--ink-faint);}
  .cat-dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:7px;}
  .row-actions{display:flex;gap:8px;}
  .row-actions button{background:none;border:1px solid var(--rule-strong);border-radius:6px;padding:6px 11px;font-size:12px;cursor:pointer;font-family:'Work Sans',sans-serif;font-weight:600;color:var(--ink-soft);}
  .row-actions button:hover{border-color:var(--navy);color:var(--navy);}
  .row-actions button.danger:hover{border-color:var(--maroon);color:var(--maroon);}
  .empty-row td{text-align:center;padding:50px 20px;color:var(--ink-faint);}

  /* editor view */
  .editor-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:22px;}
  .editor-head h2{font-family:'Domine',serif;font-size:22px;color:var(--navy);}
  .editor-grid{display:grid;grid-template-columns:1fr 300px;gap:26px;align-items:start;}
  .panel-box{background:#fff;border:1px solid var(--rule);border-radius:12px;padding:22px;margin-bottom:20px;}
  .panel-box h4{font-family:'Work Sans',sans-serif;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-faint);margin-bottom:16px;}
  .field-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
  .field textarea{resize:vertical;min-height:70px;}

  /* rich text editor */
  .rte-toolbar{display:flex;flex-wrap:wrap;gap:4px;padding:8px;border:1px solid var(--rule-strong);border-bottom:none;border-radius:7px 7px 0 0;background:var(--paper-off);}
  .rte-toolbar button{width:32px;height:32px;border:1px solid transparent;border-radius:5px;background:none;cursor:pointer;font-size:14px;color:var(--ink-soft);}
  .rte-toolbar button:hover{background:#fff;border-color:var(--rule-strong);}
  .rte-toolbar button.active{background:var(--navy);color:#fff;}
  .rte-toolbar .sep{width:1px;background:var(--rule-strong);margin:4px 4px;}
  .rte-body{border:1px solid var(--rule-strong);border-radius:0 0 7px 7px;min-height:280px;padding:16px;font-size:14.5px;line-height:1.75;}
  .rte-body:focus{outline:none;border-color:var(--navy);}
  .rte-body table{border-collapse:collapse;margin:10px 0;}
  .rte-body table td{border:1px solid var(--rule-strong);padding:6px 10px;min-width:60px;}
  .rte-body ul,.rte-body ol{margin-left:22px;}

  .thumb-preview{width:100%;aspect-ratio:16/10;border-radius:8px;background:var(--paper-off);display:flex;align-items:center;justify-content:center;overflow:hidden;margin-bottom:12px;border:1px dashed var(--rule-strong);color:var(--ink-faint);font-size:13px;}
  .thumb-preview img{width:100%;height:100%;object-fit:cover;}
  .file-row{display:flex;gap:8px;}
  .file-row label.btn{flex:1;text-align:center;background:#fff;border:1.5px solid var(--rule-strong);color:var(--ink-soft);}
  .file-row label.btn:hover{border-color:var(--navy);color:var(--navy);}
  input[type=file]{display:none;}

  .status-toggle{display:flex;border:1.5px solid var(--rule-strong);border-radius:7px;overflow:hidden;}
  .status-toggle button{flex:1;padding:10px;background:#fff;border:none;font-family:'Work Sans',sans-serif;font-weight:600;font-size:13px;cursor:pointer;color:var(--ink-soft);}
  .status-toggle button.active[data-v=draft]{background:#F0ECE1;color:var(--ink-soft);}
  .status-toggle button.active[data-v=published]{background:var(--green);color:#fff;}

  .editor-actions{display:flex;gap:10px;margin-top:6px;}
  .btn-outline{background:#fff;border:1.5px solid var(--rule-strong);color:var(--ink-soft);}
  .btn-outline:hover{border-color:var(--navy);color:var(--navy);}
  .toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(20px);background:var(--navy);color:#fff;padding:13px 22px;border-radius:8px;font-family:'Work Sans',sans-serif;font-size:13.5px;font-weight:600;opacity:0;pointer-events:none;transition:.3s ease;z-index:200;box-shadow:0 10px 30px rgba(0,0,0,.2);}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
  .toast.error{background:var(--maroon);}
  .field-error{color:var(--maroon);font-size:12.5px;margin-top:5px;display:none;}
  .extra-link-row{display:flex;gap:8px;margin-top:8px;}
  .extra-link-row input{flex:1;}
  .extra-link-row input.label-input{flex:0 0 34%;}
  .extra-link-row button{flex-shrink:0;width:36px;background:#fff;border:1px solid var(--rule-strong);border-radius:6px;color:var(--maroon);cursor:pointer;font-size:15px;}
  .extra-link-row button:hover{border-color:var(--maroon);background:#FDE8E8;}
  .source-tag{display:inline-block;font-family:'Work Sans',sans-serif;font-size:10.5px;font-weight:700;color:var(--saffron);background:var(--saffron-soft, #FCEAD3);padding:2px 8px;border-radius:10px;margin-left:6px;vertical-align:middle;}

  @media (max-width:860px){
    .editor-grid{grid-template-columns:1fr;}
    .field-row{grid-template-columns:1fr;}
    table{display:block;overflow-x:auto;white-space:nowrap;}
  }
</style>
</head>
<body>

<!-- ================= LOGIN ================= -->
<div class="login-wrap" id="loginWrap" style="<?= $loggedIn ? 'display:none' : '' ?>">
  <div class="login-card">
    <div class="mark">🏛️</div>
    <h1>Govt Jobs Panel</h1>
    <p class="sub">Sign in to write and manage listings for Rashtriya Khabar.</p>
    <div class="error-msg" id="loginError"></div>
    <form id="loginForm">
      <div class="field"><label>Username</label><input type="text" name="username" autocomplete="username" required></div>
      <div class="field"><label>Password</label><input type="password" name="password" autocomplete="current-password" required></div>
      <button type="submit" class="btn btn-navy btn-block" id="loginBtn">Sign in</button>
    </form>
  </div>
</div>

<!-- ================= APP ================= -->
<div class="app<?= $loggedIn ? ' show' : '' ?>" id="app">
  <div class="topbar">
    <div class="topbar-inner">
      <div class="topbar-brand">🏛️ Govt Jobs <span class="tag">PANEL</span></div>
      <div class="topbar-right">
        <span id="whoami"></span>
        <button id="logoutBtn">Log out</button>
      </div>
    </div>
  </div>

  <div class="main">

    <!-- ---- Dashboard view ---- -->
    <div class="view show" id="dashView">
      <div class="dash-head">
        <h2>All Listings</h2>
        <div class="dash-tools">
          <select id="filterStatus">
            <option value="">All statuses</option>
            <option value="published">Published</option>
            <option value="draft">Draft</option>
          </select>
          <input type="search" id="filterSearch" placeholder="Search title…">
          <button class="btn btn-navy" id="newPostBtn">+ New Post</button>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Title</th><th>Status</th><th>Last Date</th><th>Views</th><th>Updated</th><th></th></tr></thead>
          <tbody id="postsTableBody"><tr class="empty-row"><td colspan="6">Loading…</td></tr></tbody>
        </table>
      </div>
    </div>

    <!-- ---- Editor view ---- -->
    <div class="view" id="editorView">
      <div class="editor-head">
        <h2 id="editorTitle">New Post</h2>
        <button class="btn btn-outline" id="backToDash">← Back to list</button>
      </div>

      <form id="postForm">
        <input type="hidden" id="postId" name="id">
        <div class="editor-grid">
          <div>
            <div class="panel-box">
              <h4>Title</h4>
              <div class="field">
                <label>Post title *</label>
                <input type="text" id="fTitle" name="title" placeholder="e.g. Haryana Police Constable 2026 Notification Out" required maxlength="300">
              </div>
              <div class="field">
                <label>Organisation / Department</label>
                <input type="text" id="fOrgName" name="org_name" placeholder="e.g. Haryana Staff Selection Commission">
              </div>
              <div class="field">
                <label>Short summary (shown on cards — optional, auto-generated if blank)</label>
                <textarea id="fExcerpt" name="excerpt" maxlength="400" rows="2"></textarea>
              </div>
            </div>

            <div class="panel-box">
              <h4>Full details</h4>
              <div class="field">
                <label>Post content *</label>
                <div class="rte-toolbar" id="rteToolbar">
                  <button type="button" data-cmd="bold" title="Bold"><b>B</b></button>
                  <button type="button" data-cmd="italic" title="Italic"><i>I</i></button>
                  <button type="button" data-cmd="underline" title="Underline"><u>U</u></button>
                  <div class="sep"></div>
                  <button type="button" data-cmd="formatBlock" data-val="h3" title="Heading">H</button>
                  <button type="button" data-cmd="formatBlock" data-val="blockquote" title="Notice quote">❝</button>
                  <div class="sep"></div>
                  <button type="button" data-cmd="insertUnorderedList" title="Bullet list">•≡</button>
                  <button type="button" data-cmd="insertOrderedList" title="Numbered list">1≡</button>
                  <div class="sep"></div>
                  <button type="button" data-cmd="createLink" title="Insert link">🔗</button>
                  <button type="button" data-cmd="insertTable" title="Insert table (e.g. important dates / fee)">▦</button>
                  <div class="sep"></div>
                  <button type="button" data-cmd="undo" title="Undo">↶</button>
                  <button type="button" data-cmd="redo" title="Redo">↷</button>
                </div>
                <div class="rte-body" id="rteBody" contenteditable="true"></div>
                <div class="field-error" id="bodyError">Post content is required.</div>
              </div>
            </div>

            <div class="panel-box">
              <h4>Links</h4>
              <div class="field-row">
                <div class="field"><label>Official notification link (PDF etc.)</label><input type="url" id="fOfficialLink" name="official_link" placeholder="https://…"></div>
                <div class="field"><label>Apply online link</label><input type="url" id="fApplyLink" name="apply_link" placeholder="https://…"></div>
              </div>
              <div class="field">
                <label>Other links (Admit Card Download, Result, Syllabus PDF, etc. — add as many as you need)</label>
                <div id="extraLinksList"></div>
                <button type="button" class="btn btn-outline" id="addExtraLinkBtn" style="margin-top:8px;">+ Add another link</button>
              </div>
            </div>

            <div class="panel-box">
              <h4>Important dates (optional)</h4>
              <div class="field-row">
                <div class="field"><label>Start date</label><input type="date" id="fStartDate" name="start_date"></div>
                <div class="field"><label>Last date to apply</label><input type="date" id="fLastDate" name="last_date"></div>
              </div>
              <div class="field"><label>Exam date</label><input type="date" id="fExamDate" name="exam_date"></div>
            </div>
          </div>

          <div>
            <div class="panel-box">
              <h4>Thumbnail</h4>
              <div class="thumb-preview" id="thumbPreview">No image selected</div>
              <div class="file-row">
                <label class="btn" for="fThumbnail">Choose image</label>
                <input type="file" id="fThumbnail" name="thumbnail" accept="image/jpeg,image/png,image/webp">
              </div>
              <button type="button" class="btn btn-outline btn-block" id="removeThumbBtn" style="margin-top:8px;display:none;">Remove image</button>
              <input type="hidden" id="removeThumbnailFlag" name="remove_thumbnail" value="0">
            </div>

            <div class="panel-box">
              <h4>Status</h4>
              <div class="status-toggle" id="statusToggle">
                <button type="button" data-v="draft" class="active">Draft</button>
                <button type="button" data-v="published">Published</button>
              </div>
              <input type="hidden" id="fStatus" name="status" value="draft">
            </div>

            <div class="editor-actions">
              <button type="submit" class="btn btn-navy" id="saveBtn" style="flex:1;">Save Post</button>
            </div>
          </div>
        </div>
      </form>
    </div>

  </div>
</div>

<div class="toast" id="toast"></div>

<script>
/* ============================================================
   Login
   ============================================================ */
document.getElementById('loginForm')?.addEventListener('submit', function(e){
  e.preventDefault();
  var btn = document.getElementById('loginBtn');
  var err = document.getElementById('loginError');
  err.classList.remove('show');
  btn.disabled = true; btn.textContent = 'Signing in…';
  fetch('jobs-api/login.php', { method:'POST', body:new FormData(this) })
    .then(r => r.json())
    .then(function(data){
      if(!data.ok){ err.textContent = data.error; err.classList.add('show'); return; }
      document.getElementById('loginWrap').style.display = 'none';
      document.getElementById('app').classList.add('show');
      document.getElementById('whoami').textContent = 'Signed in as ' + data.name;
      loadDashboard();
    })
    .catch(function(){ err.textContent = 'Something went wrong. Try again.'; err.classList.add('show'); })
    .finally(function(){ btn.disabled = false; btn.textContent = 'Sign in'; });
});

document.getElementById('logoutBtn')?.addEventListener('click', function(){
  fetch('jobs-api/logout.php', {method:'POST'}).then(function(){ window.location.reload(); });
});

/* ============================================================
   View switching
   ============================================================ */
function showView(name){
  document.querySelectorAll('.view').forEach(v => v.classList.remove('show'));
  document.getElementById(name).classList.add('show');
}
document.getElementById('newPostBtn')?.addEventListener('click', function(){ openEditor(null); });
document.getElementById('backToDash')?.addEventListener('click', function(){ showView('dashView'); loadDashboard(); });

/* ============================================================
   Toast
   ============================================================ */
var toastTimer;
function showToast(msg, isError){
  var t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show' + (isError ? ' error' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ t.classList.remove('show'); }, 3200);
}

/* ============================================================
   Dashboard
   ============================================================ */
var allPosts = [];

function loadDashboard(){
  var tbody = document.getElementById('postsTableBody');
  tbody.innerHTML = '<tr class="empty-row"><td colspan="6">Loading…</td></tr>';
  fetch('jobs-api/admin_list.php').then(r => r.json()).then(function(data){
    if(!data.ok){ tbody.innerHTML = '<tr class="empty-row"><td colspan="6">Could not load posts.</td></tr>'; return; }
    allPosts = data.posts;
    renderTable();
  }).catch(function(){ tbody.innerHTML = '<tr class="empty-row"><td colspan="6">Could not load posts.</td></tr>'; });
}

function renderTable(){
  var status = document.getElementById('filterStatus').value;
  var q = document.getElementById('filterSearch').value.toLowerCase();
  var rows = allPosts.filter(function(p){
    if(status && p.status !== status) return false;
    if(q && p.title.toLowerCase().indexOf(q) === -1) return false;
    return true;
  });
  var tbody = document.getElementById('postsTableBody');
  if(!rows.length){ tbody.innerHTML = '<tr class="empty-row"><td colspan="6">No posts match. Try “+ New Post” to add your first listing.</td></tr>'; return; }
  tbody.innerHTML = rows.map(function(p){
    return '<tr>' +
      '<td><b>'+escapeHTML(p.title)+'</b>' + (p.source_name ? ' <span class="source-tag" title="Auto-fetched from '+escapeHTML(p.source_name)+'">⚡ '+escapeHTML(p.source_name)+'</span>' : '') + '</td>' +
      '<td><span class="status-pill '+p.status+'">'+p.status+'</span></td>' +
      '<td>'+(p.last_date || '—')+'</td>' +
      '<td>'+p.views+'</td>' +
      '<td>'+(p.updated_at ? p.updated_at.slice(0,16).replace('T',' ') : '—')+'</td>' +
      '<td><div class="row-actions">' +
        '<button type="button" onclick="openEditor('+p.id+')">Edit</button>' +
        (p.status === 'published' ? '<button type="button" onclick="window.open(\'/jobs/'+encodeURIComponent(p.slug)+'/\',\'_blank\')">View</button>' : '') +
        '<button type="button" class="danger" onclick="deletePost('+p.id+',\''+escapeHTML(p.title).replace(/'/g,"\\'")+'\')">Delete</button>' +
      '</div></td>' +
    '</tr>';
  }).join('');
}
function escapeHTML(s){ var d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }

document.getElementById('filterStatus')?.addEventListener('change', renderTable);
document.getElementById('filterSearch')?.addEventListener('input', renderTable);

window.deletePost = function(id, title){
  if(!confirm('Delete "'+title+'"? This cannot be undone.')) return;
  var fd = new FormData(); fd.append('id', id);
  fetch('jobs-api/delete.php', {method:'POST', body:fd}).then(r => r.json()).then(function(data){
    if(data.ok){ showToast('Post deleted.'); loadDashboard(); } else { showToast(data.error || 'Could not delete.', true); }
  });
};

/* ============================================================
   Rich text editor
   ============================================================ */
var rteBody = document.getElementById('rteBody');
document.getElementById('rteToolbar')?.addEventListener('click', function(e){
  var btn = e.target.closest('button'); if(!btn) return;
  rteBody.focus();
  var cmd = btn.getAttribute('data-cmd');
  if(cmd === 'createLink'){
    var url = prompt('Link URL (https://…)');
    if(url) document.execCommand('createLink', false, url);
  } else if(cmd === 'insertTable'){
    document.execCommand('insertHTML', false,
      '<table><tr><td>Item</td><td>Detail</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr></table><p><br></p>');
  } else if(cmd === 'formatBlock'){
    document.execCommand('formatBlock', false, btn.getAttribute('data-val'));
  } else {
    document.execCommand(cmd, false, null);
  }
});

/* ============================================================
   Status toggle
   ============================================================ */
document.getElementById('statusToggle')?.addEventListener('click', function(e){
  var btn = e.target.closest('button'); if(!btn) return;
  document.querySelectorAll('#statusToggle button').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('fStatus').value = btn.getAttribute('data-v');
});

/* ============================================================
   Thumbnail preview
   ============================================================ */
document.getElementById('fThumbnail')?.addEventListener('change', function(e){
  var file = e.target.files[0];
  if(!file) return;
  var reader = new FileReader();
  reader.onload = function(ev){
    document.getElementById('thumbPreview').innerHTML = '<img src="'+ev.target.result+'">';
    document.getElementById('removeThumbBtn').style.display = 'block';
    document.getElementById('removeThumbnailFlag').value = '0';
  };
  reader.readAsDataURL(file);
});
document.getElementById('removeThumbBtn')?.addEventListener('click', function(){
  document.getElementById('fThumbnail').value = '';
  document.getElementById('thumbPreview').innerHTML = 'No image selected';
  document.getElementById('removeThumbBtn').style.display = 'none';
  document.getElementById('removeThumbnailFlag').value = '1';
});

/* ============================================================
   Editor: open / populate / reset
   ============================================================ */
/* ---- Extra links (repeatable Admit Card / Result / etc. link rows) ---- */
function addExtraLinkRow(label, url){
  var row = document.createElement('div');
  row.className = 'extra-link-row';
  row.innerHTML =
    '<input type="text" class="label-input" name="extra_link_label[]" placeholder="Label, e.g. Admit Card Download" value="'+escapeAttr(label||'')+'">' +
    '<input type="url" name="extra_link_url[]" placeholder="https://…" value="'+escapeAttr(url||'')+'">' +
    '<button type="button" title="Remove">✕</button>';
  row.querySelector('button').addEventListener('click', function(){ row.remove(); });
  document.getElementById('extraLinksList').appendChild(row);
}
function escapeAttr(s){ return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;'); }
document.getElementById('addExtraLinkBtn')?.addEventListener('click', function(){ addExtraLinkRow('',''); });

function resetEditor(){
  document.getElementById('postForm').reset();
  document.getElementById('postId').value = '';
  rteBody.innerHTML = '';
  document.getElementById('thumbPreview').innerHTML = 'No image selected';
  document.getElementById('removeThumbBtn').style.display = 'none';
  document.getElementById('removeThumbnailFlag').value = '0';
  document.getElementById('extraLinksList').innerHTML = '';
  document.querySelectorAll('#statusToggle button').forEach(b => b.classList.remove('active'));
  document.querySelector('#statusToggle button[data-v=draft]').classList.add('active');
  document.getElementById('fStatus').value = 'draft';
  document.getElementById('bodyError').style.display = 'none';
}

window.openEditor = function(id){
  resetEditor();
  document.getElementById('editorTitle').textContent = id ? 'Edit Post' : 'New Post';
  showView('editorView');
  if(!id) return;
  fetch('jobs-api/get.php?id=' + id).then(r => r.json()).then(function(data){
    if(!data.ok){ showToast(data.error || 'Could not load post.', true); return; }
    var p = data.post;
    document.getElementById('postId').value = p.id;
    document.getElementById('fTitle').value = p.title;
    document.getElementById('fOrgName').value = p.org_name || '';
    document.getElementById('fExcerpt').value = p.excerpt || '';
    rteBody.innerHTML = p.body || '';
    document.getElementById('fOfficialLink').value = p.official_link || '';
    document.getElementById('fApplyLink').value = p.apply_link || '';
    document.getElementById('fStartDate').value = p.start_date || '';
    document.getElementById('fLastDate').value = p.last_date || '';
    document.getElementById('fExamDate').value = p.exam_date || '';
    (p.extra_links || []).forEach(function(l){ addExtraLinkRow(l.label, l.url); });
    document.querySelectorAll('#statusToggle button').forEach(function(b){
      b.classList.toggle('active', b.getAttribute('data-v') === p.status);
    });
    document.getElementById('fStatus').value = p.status;
    if(p.thumbnail_url){
      document.getElementById('thumbPreview').innerHTML = '<img src="'+p.thumbnail_url+'">';
      document.getElementById('removeThumbBtn').style.display = 'block';
    }
  }).catch(function(){ showToast('Could not load post.', true); });
};

/* ============================================================
   Save (create or update)
   ============================================================ */
document.getElementById('postForm').addEventListener('submit', function(e){
  e.preventDefault();
  var bodyHTML = rteBody.innerHTML.trim();
  var bodyErr = document.getElementById('bodyError');
  if(!rteBody.textContent.trim()){ bodyErr.style.display = 'block'; rteBody.focus(); return; }
  bodyErr.style.display = 'none';

  var fd = new FormData(this);
  fd.set('body', bodyHTML);
  var fileInput = document.getElementById('fThumbnail');
  if(fileInput.files[0]) fd.set('thumbnail', fileInput.files[0]);

  var btn = document.getElementById('saveBtn');
  btn.disabled = true; btn.textContent = 'Saving…';
  fetch('jobs-api/save.php', { method:'POST', body:fd })
    .then(r => r.json())
    .then(function(data){
      if(!data.ok){ showToast(data.error || 'Could not save.', true); return; }
      showToast('Saved.');
      showView('dashView');
      loadDashboard();
    })
    .catch(function(){ showToast('Something went wrong.', true); })
    .finally(function(){ btn.disabled = false; btn.textContent = 'Save Post'; });
});

/* ============================================================
   Boot
   ============================================================ */
<?php if ($loggedIn): ?>
document.getElementById('whoami').textContent = 'Signed in as <?= htmlspecialchars($_SESSION['admin_name'] ?? 'admin', ENT_QUOTES) ?>';
loadDashboard();
<?php endif; ?>
</script>
</body>
</html>
