<?php
require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';

$slug = $_GET['slug'] ?? '';
if ($slug === '') { http_response_code(404); }

$stmt = db()->prepare('SELECT * FROM posts WHERE slug = ? AND status = "published"');
$stmt->execute([$slug]);
$post = $stmt->fetch();

if (!$post) {
    http_response_code(404);
}

if ($post) {
    $_SESSION['viewed'] = $_SESSION['viewed'] ?? [];
    if (empty($_SESSION['viewed'][$post['id']])) {
        db()->prepare('UPDATE posts SET views = views + 1 WHERE id = ?')->execute([$post['id']]);
        $_SESSION['viewed'][$post['id']] = true;
        $post['views'] += 1;
    }
}

$related = [];
if ($post) {
    $r = db()->prepare('SELECT slug, title, thumbnail, published_at FROM posts
                         WHERE status="published" AND id != ?
                         ORDER BY published_at DESC LIMIT 3');
    $r->execute([$post['id']]);
    $related = $r->fetchAll();
}

function fmt_date_php($iso) {
    if (!$iso) return '';
    return (new DateTime($iso))->format('d M Y');
}

$extraLinks = $post ? parse_extra_links($post['extra_links']) : [];
$pageTitle = $post ? $post['title'] . ' — Rashtriya Khabar' : 'Post not found — Rashtriya Khabar';
$pageDesc  = $post ? ($post['excerpt'] ?: mb_substr(trim(strip_tags($post['body'])), 0, 160)) : 'This listing could not be found.';
$pageImg   = $post && $post['thumbnail'] ? (defined('SITE_URL') ? SITE_URL : '') . UPLOAD_URL . '/' . $post['thumbnail'] : '';
$canonical = (defined('SITE_URL') ? SITE_URL : '') . '/jobs/' . urlencode($slug) . '/';
?>
<!DOCTYPE html>
<html lang="en" id="htmlRoot">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<meta name="description" content="<?= htmlspecialchars($pageDesc) ?>">
<link rel="canonical" href="<?= htmlspecialchars($canonical) ?>">
<meta property="og:type" content="article">
<meta property="og:title" content="<?= htmlspecialchars($post['title'] ?? 'Not found') ?>">
<meta property="og:description" content="<?= htmlspecialchars($pageDesc) ?>">
<meta property="og:url" content="<?= htmlspecialchars($canonical) ?>">
<?php if ($pageImg): ?><meta property="og:image" content="<?= htmlspecialchars($pageImg) ?>"><?php endif; ?>
<meta property="og:site_name" content="Rashtriya Khabar">
<meta name="twitter:card" content="<?= $pageImg ? 'summary_large_image' : 'summary' ?>">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%23E50914'/%3E%3Ccircle cx='44' cy='44' r='16' fill='%23FF9933'/%3E%3Ctext x='34' y='45' font-family='Arial Black,sans-serif' font-size='15' font-weight='900' fill='%23FFFFFF'%3E.in%3C/text%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Tiro+Devanagari+Hindi:ital@0;1&family=Domine:wght@400;500;600;700&family=Hind:wght@300;400;500;600;700&family=Work+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root{
    --paper:#FFFFFF; --paper-off:#FAF8F2; --ink:#18130F; --ink-soft:#544C42; --ink-faint:#8A8177;
    --navy:#0B2545; --navy-deep:#081A31; --saffron:#E8710A; --saffron-soft:#FCEAD3;
    --maroon:#A61B29; --green:#134D2C; --gold:#C99A2E; --rule:#E6E0D2; --rule-strong:#D8CFBB;
  }
  *{margin:0;padding:0;box-sizing:border-box;}
  html{scroll-behavior:smooth;}
  body{background:var(--paper);color:var(--ink);font-family:'Hind',sans-serif;-webkit-font-smoothing:antialiased;line-height:1.6;}
  .wrap{max-width:1200px;margin:0 auto;padding:0 24px;}
  a{color:inherit;text-decoration:none;}
  img,svg{display:block;max-width:100%;}
  button{font:inherit;}
  .site-header{position:sticky;top:0;z-index:80;background:var(--paper);}
  .masthead{border-bottom:2px solid var(--rule);background:linear-gradient(to bottom, rgba(255,255,255,1) 0%, rgba(250,248,242,1) 100%);}
  .masthead-inner{display:flex;align-items:center;justify-content:space-between;padding:14px 0;gap:12px;}
  .brand{display:flex;flex-direction:column;align-items:flex-start;min-width:0;}
  .logo-mark svg{width:280px;max-width:100%;height:auto;display:block;}
  .nav-toggle{display:none;background:none;border:1px solid var(--rule-strong);color:var(--navy);align-items:center;gap:7px;padding:8px 12px;cursor:pointer;border-radius:6px;font-family:'Work Sans',sans-serif;font-size:13px;font-weight:600;}
  .nav-bar{background:linear-gradient(135deg, var(--navy-deep) 0%, var(--navy) 100%);border-top:2px solid var(--saffron);}
  .nav-bar-row{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;}
  .nav-inner{display:flex;align-items:center;justify-content:center;}
  .nav-inner a{font-family:'Work Sans',sans-serif;font-size:13.5px;font-weight:500;color:#EDF1F6;padding:13px 15px;display:inline-block;position:relative;}
  .nav-inner a:hover{background:rgba(255,255,255,.08);color:#fff;}
  .nav-inner a.govt-jobs{background:linear-gradient(135deg, #E8710A 0%, #C25608 100%);color:#fff !important;font-weight:700;border-radius:4px;margin:5px 8px;padding:8px 14px;font-size:12.5px;box-shadow:0 2px 8px rgba(232,113,10,.4);}
  .breadcrumb{font-family:'Work Sans',sans-serif;font-size:12px;color:var(--ink-faint);padding:20px 0 0;}
  .breadcrumb a:hover{color:var(--navy);text-decoration:underline;}
  .article-grid{display:grid;grid-template-columns:1fr 320px;gap:44px;padding:20px 0 64px;align-items:start;}
  article h1{font-family:'Domine',serif;font-size:clamp(26px,3.4vw,38px);font-weight:700;color:var(--navy);line-height:1.28;letter-spacing:-.01em;margin-bottom:16px;}
  .article-meta{font-family:'Work Sans',sans-serif;font-size:13px;color:var(--ink-faint);display:flex;flex-wrap:wrap;gap:14px;padding-bottom:22px;border-bottom:1px solid var(--rule);margin-bottom:26px;}
  .article-meta b{color:var(--ink-soft);font-weight:600;}
  .featured-thumb{width:100%;border-radius:10px;overflow:hidden;margin-bottom:28px;background:var(--paper-off);}
  .featured-thumb img{width:100%;height:auto;display:block;}
  .article-body{font-size:16px;line-height:1.85;color:var(--ink);}
  .article-body p{margin-bottom:16px;}
  .article-body ul,.article-body ol{margin:0 0 16px 22px;}
  .article-body li{margin-bottom:6px;}
  .article-body h2,.article-body h3{font-family:'Domine',serif;color:var(--navy);margin:26px 0 12px;}
  .article-body table{width:100%;border-collapse:collapse;margin:18px 0;font-size:14.5px;}
  .article-body table td,.article-body table th{border:1px solid var(--rule-strong);padding:9px 12px;text-align:left;}
  .article-body table th{background:var(--paper-off);font-weight:600;}
  .article-body a{color:var(--navy);text-decoration:underline;text-decoration-color:var(--rule-strong);}
  .article-body blockquote{border-left:3px solid var(--saffron);padding:4px 0 4px 16px;color:var(--ink-soft);font-style:italic;margin:16px 0;}
  .share-row{display:flex;gap:10px;margin-top:32px;padding-top:24px;border-top:1px solid var(--rule);flex-wrap:wrap;}
  .share-btn{display:inline-flex;align-items:center;gap:8px;font-family:'Work Sans',sans-serif;font-size:13px;font-weight:600;padding:10px 18px;border-radius:6px;border:1.5px solid var(--rule-strong);color:var(--ink-soft);transition:.2s ease;}
  .share-btn.whatsapp{border-color:#25D366;color:#128C4A;}
  .share-btn.whatsapp:hover{background:#25D366;color:#fff;}
  .share-btn.copy:hover{border-color:var(--navy);color:var(--navy);}
  .quick-facts{background:var(--paper-off);border:1px solid var(--rule);border-radius:12px;padding:22px;position:sticky;top:90px;}
  .quick-facts h4{font-family:'Work Sans',sans-serif;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-faint);margin-bottom:16px;}
  .fact-row{display:flex;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid var(--rule);font-size:13.5px;}
  .fact-row:last-of-type{border-bottom:none;}
  .fact-row .k{color:var(--ink-faint);}
  .fact-row .v{color:var(--ink);font-weight:600;text-align:right;}
  .quick-facts .cta{display:block;text-align:center;font-family:'Work Sans',sans-serif;font-weight:700;font-size:13.5px;padding:12px;border-radius:7px;margin-top:14px;transition:.2s ease;}
  .cta.primary{background:var(--navy);color:#fff;}
  .cta.primary:hover{background:var(--saffron);}
  .cta.outline{border:1.5px solid var(--navy);color:var(--navy);}
  .cta.outline:hover{background:var(--navy);color:#fff;}
  .cta.small{padding:9px;font-size:12.5px;}
  .related-section{padding:10px 0 60px;border-top:1px solid var(--rule);margin-top:10px;}
  .related-section h3{font-family:'Domine',serif;font-size:20px;color:var(--navy);margin:30px 0 20px;}
  .related-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;}
  .related-card{border:1px solid var(--rule);border-radius:10px;padding:14px;transition:.2s ease;display:block;}
  .related-card:hover{border-color:var(--navy);transform:translateY(-3px);}
  .related-card h4{font-family:'Domine',serif;font-size:15px;margin-top:6px;line-height:1.4;}
  .not-found{text-align:center;padding:100px 20px;}
  .not-found h1{font-family:'Domine',serif;font-size:32px;color:var(--navy);margin-bottom:12px;}
  .not-found a{color:var(--saffron);font-weight:600;text-decoration:underline;}
  footer{background:var(--navy-deep);color:#B9C5D6;padding:40px 0 26px;margin-top:20px;}
  .footer-bottom{display:flex;justify-content:space-between;align-items:center;padding:0 0;font-family:'Work Sans',sans-serif;font-size:12px;color:#8298B3;flex-wrap:wrap;gap:10px;}
  footer a:hover{color:var(--saffron);}
  @media (max-width:900px){
    .article-grid{grid-template-columns:1fr;}
    .quick-facts{position:static;}
    .related-grid{grid-template-columns:1fr 1fr;}
  }
  @media (max-width:768px){
    .nav-toggle{display:flex;}
    .nav-bar-row{justify-content:flex-start;}
    .nav-inner{flex-basis:100%;flex-direction:column;align-items:flex-start;max-height:0;overflow:hidden;transition:max-height .35s ease;width:100%;}
    .nav-bar.open .nav-inner{max-height:520px;}
    .nav-inner a{padding:12px 16px;width:100%;border-bottom:1px solid rgba(255,255,255,.08);font-size:15px;}
    .wrap{padding:0 16px;}
  }
  @media (max-width:640px){
    .related-grid{grid-template-columns:1fr;}
    .logo-mark svg{width:185px;}
  }
</style>
</head>
<body>
<header class="site-header" id="siteHeader">
  <div class="masthead">
    <div class="wrap masthead-inner">
      <div class="brand">
        <a href="index.html" class="logo-mark" aria-label="Rashtriya Khabar home">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 110" width="280" role="img" aria-label="Rashtriya Khabar">
            <rect x="0" y="4" width="148" height="62" rx="7" fill="#E50914"/>
            <text x="74" y="47" text-anchor="middle" font-family="'Noto Sans Devanagari','Mangal','Arial Unicode MS',sans-serif" font-size="34" font-weight="900" fill="#FFFFFF">राष्ट्रीय</text>
            <text x="164" y="47" font-family="'Noto Sans Devanagari','Mangal','Arial Unicode MS',sans-serif" font-size="36" font-weight="900" fill="#0B2545">ख़बर</text>
            <circle cx="298" cy="20" r="17" fill="#FF9933"/>
            <text x="298" y="24" text-anchor="middle" font-family="'Arial Black','Arial',sans-serif" font-size="13" font-weight="900" fill="#FFFFFF">.in</text>
            <rect x="0" y="72" width="310" height="3" rx="1.5" fill="url(#logoGrad)"/>
            <defs><linearGradient id="logoGrad" x1="0" y1="0" x2="310" y2="0"><stop offset="0%" stop-color="#E50914"/><stop offset="45%" stop-color="#FF9933"/><stop offset="100%" stop-color="#134D2C"/></linearGradient></defs>
            <text x="0" y="96" font-family="'Work Sans','Hind',sans-serif" font-size="11" font-weight="600" fill="#8A8177" letter-spacing="2.5">सच · सबसे पहले · हर पल</text>
          </svg>
        </a>
      </div>
      <button class="nav-toggle" id="navToggle" aria-label="मेनू खोलें" aria-expanded="false">
        <svg width="18" height="13" viewBox="0 0 18 13" aria-hidden="true"><rect width="18" height="1.6" fill="currentColor"/><rect y="5.5" width="18" height="1.6" fill="currentColor"/><rect y="11" width="18" height="1.6" fill="currentColor"/></svg>
        मेनू
      </button>
    </div>
  </div>
  <nav class="nav-bar" id="navBar">
    <div class="wrap nav-bar-row">
      <div class="nav-inner" id="navInner">
        <a href="index.html#hero">Home</a>
        <a href="index.html#politicsSection">Politics</a>
        <a href="index.html#justInSection">India</a>
        <a href="index.html#trendingSection">World</a>
        <a href="index.html#marketSection">Business</a>
        <a href="index.html#sportsEntSection">Sports</a>
        <a href="index.html#sportsEntSection">Entertainment</a>
        <a href="index.html#editorialSection">Opinion</a>
        <a href="/jobs" class="govt-jobs"><svg width="13" height="13" viewBox="0 0 20 20" fill="none" style="vertical-align:-2px;margin-right:4px;" aria-hidden="true"><path d="M3 8L10 3L17 8" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><rect x="4" y="8" width="12" height="8" stroke="#fff" stroke-width="1.6"/><rect x="8.5" y="11" width="3" height="5" stroke="#fff" stroke-width="1.4"/></svg>Govt Jobs</a>
      </div>
    </div>
  </nav>
</header>

<?php if (!$post): ?>
  <div class="not-found">
    <h1>This listing couldn't be found</h1>
    <p style="color:var(--ink-soft);margin-bottom:18px;">It may have been removed, or the link might be incorrect.</p>
    <a href="/jobs">← Back to Govt Jobs</a>
  </div>
<?php else: ?>

  <div class="wrap breadcrumb">
    <a href="/jobs">Govt Jobs</a> &nbsp;›&nbsp; <span><?= htmlspecialchars(mb_substr($post['title'],0,60)) ?></span>
  </div>

  <div class="wrap article-grid">
    <article>
      <h1><?= htmlspecialchars($post['title']) ?></h1>
      <div class="article-meta">
        <?php if ($post['org_name']): ?><span><b><?= htmlspecialchars($post['org_name']) ?></b></span><?php endif; ?>
        <span>📅 <?= fmt_date_php($post['published_at']) ?></span>
        <span>👁 <?= (int)$post['views'] ?> views</span>
      </div>

      <?php if ($post['thumbnail']): ?>
        <div class="featured-thumb"><img src="<?= UPLOAD_URL . '/' . htmlspecialchars($post['thumbnail']) ?>" alt="<?= htmlspecialchars($post['title']) ?>"></div>
      <?php endif; ?>

      <div class="article-body"><?= $post['body'] ?></div>

      <div class="share-row">
        <a class="share-btn whatsapp" target="_blank" rel="noopener"
           href="https://wa.me/?text=<?= urlencode($post['title'] . ' — ' . $canonical) ?>">
           📱 Share on WhatsApp
        </a>
        <button class="share-btn copy" onclick="navigator.clipboard.writeText(window.location.href).then(()=>{this.textContent='✓ Link copied';setTimeout(()=>{this.textContent='🔗 Copy link';},1800);});">🔗 Copy link</button>
      </div>
    </article>

    <aside class="quick-facts">
      <h4>Quick Facts</h4>
      <?php if ($post['start_date']): ?><div class="fact-row"><span class="k">Start Date</span><span class="v"><?= fmt_date_php($post['start_date']) ?></span></div><?php endif; ?>
      <?php if ($post['last_date']): ?><div class="fact-row"><span class="k">Last Date</span><span class="v"><?= fmt_date_php($post['last_date']) ?></span></div><?php endif; ?>
      <?php if ($post['exam_date']): ?><div class="fact-row"><span class="k">Exam Date</span><span class="v"><?= fmt_date_php($post['exam_date']) ?></span></div><?php endif; ?>
      <?php if ($post['org_name']): ?><div class="fact-row"><span class="k">Organisation</span><span class="v"><?= htmlspecialchars($post['org_name']) ?></span></div><?php endif; ?>
      <?php if ($post['apply_link']): ?><a class="cta primary" target="_blank" rel="noopener" href="<?= htmlspecialchars($post['apply_link']) ?>">Apply Online →</a><?php endif; ?>
      <?php if ($post['official_link']): ?><a class="cta outline" target="_blank" rel="noopener" href="<?= htmlspecialchars($post['official_link']) ?>">Official Notification (PDF)</a><?php endif; ?>
      <?php foreach ($extraLinks as $link): ?>
        <a class="cta outline small" target="_blank" rel="noopener" href="<?= htmlspecialchars($link['url']) ?>"><?= htmlspecialchars($link['label']) ?> →</a>
      <?php endforeach; ?>
    </aside>
  </div>

  <?php if ($related): ?>
  <div class="wrap related-section">
    <h3>More Govt Jobs listings</h3>
    <div class="related-grid">
      <?php foreach ($related as $r): ?>
        <a class="related-card" href="/jobs/<?= urlencode($r['slug']) ?>/">
          <h4><?= htmlspecialchars($r['title']) ?></h4>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

<?php endif; ?>

<footer>
  <div class="wrap footer-bottom">
    <span>© 2026 Rashtriya Khabar. All rights reserved.</span>
    <a href="/jobs">← Back to all Govt Jobs listings</a>
  </div>
</footer>

<script>
  var navToggle = document.getElementById('navToggle');
  var navBar = document.getElementById('navBar');
  navToggle.addEventListener('click', function(){
    var open = navBar.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', open);
  });
</script>
</body>
</html>
