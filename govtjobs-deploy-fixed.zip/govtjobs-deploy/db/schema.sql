-- ============================================================
-- Rashtriya Khabar — Govt Jobs section (simple blog-style, no categories)
-- Database schema (MySQL 8.0 / MariaDB compatible)
-- Run once:  mysql -u govtjobs_app -p govtjobs < schema.sql
-- ============================================================

SET NAMES utf8mb4;

-- ---------- Admin accounts (people who can use the panel) ----------
CREATE TABLE IF NOT EXISTS admin_users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(60)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  display_name  VARCHAR(100) NOT NULL DEFAULT '',
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Job posts — one simple reverse-chronological blog feed ----------
CREATE TABLE IF NOT EXISTS posts (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slug           VARCHAR(220)  NOT NULL UNIQUE,
  title          VARCHAR(300)  NOT NULL,
  org_name       VARCHAR(200)  NULL,        -- e.g. "SSC", "Indian Railways (RRB)", "UPSC"
  excerpt        VARCHAR(400)  NULL,        -- short summary for cards; falls back to trimmed body if empty
  body           LONGTEXT      NOT NULL,    -- rich HTML from the panel editor
  thumbnail      VARCHAR(255)  NULL,        -- relative path under /uploads/thumbs/
  official_link  VARCHAR(500)  NULL,        -- primary CTA: official notification / PDF
  apply_link     VARCHAR(500)  NULL,        -- primary CTA: apply online portal
  extra_links    TEXT          NULL,        -- JSON array of {label,url} — Admit Card, Result, Syllabus, etc.
  start_date     DATE NULL,
  last_date      DATE NULL,
  exam_date      DATE NULL,
  status         ENUM('draft','published') NOT NULL DEFAULT 'draft',
  source_name    VARCHAR(120)  NULL,        -- optional: where a fetched draft came from (shown only in the panel, never on the public page)
  source_url     VARCHAR(500)  NULL,
  views          INT UNSIGNED NOT NULL DEFAULT 0,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  published_at   TIMESTAMP NULL,
  KEY idx_status_pub (status, published_at),
  UNIQUE KEY uniq_source_url (source_url)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
