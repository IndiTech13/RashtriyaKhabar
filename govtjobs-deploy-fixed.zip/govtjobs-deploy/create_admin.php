<?php
/**
 * One-time (or whenever-you-need-it) CLI tool to create or reset the
 * panel's admin login. Never runs over the web — only from the terminal.
 *
 * Usage:
 *   php create_admin.php <username>
 *   php create_admin.php <username> "<password>"     (skip the interactive prompt)
 *
 * Re-running it with the same username resets that user's password.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    die('This script can only be run from the command line.');
}

require_once '/etc/govtjobs/config.php';

$username = $argv[1] ?? null;
if (!$username) {
    fwrite(STDERR, "Usage: php create_admin.php <username> [\"password\"]\n");
    exit(1);
}

$password = $argv[2] ?? null;
if (!$password) {
    echo "Password for '$username': ";
    // Hide input where the terminal supports it (falls back to visible on Windows-ish shells).
    system('stty -echo 2>/dev/null');
    $password = trim(fgets(STDIN));
    system('stty echo 2>/dev/null');
    echo "\n";
}

if (strlen($password) < 8) {
    fwrite(STDERR, "Password must be at least 8 characters.\n");
    exit(1);
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$pdo = db();

$stmt = $pdo->prepare('SELECT id FROM admin_users WHERE username = ?');
$stmt->execute([$username]);
$existing = $stmt->fetch();

if ($existing) {
    $upd = $pdo->prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?');
    $upd->execute([$hash, $existing['id']]);
    echo "Password updated for existing user '$username'.\n";
} else {
    $ins = $pdo->prepare('INSERT INTO admin_users (username, password_hash, display_name) VALUES (?, ?, ?)');
    $ins->execute([$username, $hash, $username]);
    echo "Admin user '$username' created.\n";
}

echo "You can now log in at panel.php with this username and password.\n";
