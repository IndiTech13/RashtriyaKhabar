# Adding Govt Jobs to your live Rashtriya Khabar site

This assumes your main site is already running per your own `SETUP.md` —
Nginx serving `index.html`, the Node.js article-proxy on PM2 (port 3001).
This guide covers exactly what's *new*: the Govt Jobs pages, their PHP
backend, MySQL, and the Nginx config changes to wire it all in — without
touching how your existing site or article-proxy work.

**Nothing here conflicts with what you already have.** The jobs system's
API lives at `/jobs-api/*` specifically so it never collides with your
existing `/api/` (that stays 100% the Node article-proxy, untouched).

---

## What's in this folder

```
webroot/                    → the CONTENTS of this go into /var/www/rashtriyakhabar,
                                as siblings of your existing index.html
  job.html                    the public listing page — reachable at /jobs
  post.php                    individual post page (Open Graph tags for WhatsApp/FB previews)
  panel.php                   the login + writing panel
  jobs-api/                    JSON endpoints (renamed from "api/" specifically to avoid
                                colliding with your existing /api/ article-proxy route)
  uploads/thumbs/              where uploaded thumbnail images are stored

etc-govtjobs/                → goes OUTSIDE the docroot, at /etc/govtjobs — this is
                                deliberate: it's how the DB password and any API keys
                                stay out of your git repo entirely, so a `git pull`
                                can never touch or expose them
  config.php                  database connection + site settings (EDIT THIS)
  helpers.php, fetch_helpers.php, ai_writer.php    shared PHP code

db/schema.sql                database tables — import this once
create_admin.php             CLI tool to create/reset your panel login
fetch_jobs.php                optional auto-fetch script (see bottom section)
nginx-rashtriyakhabar.conf    your OWN config file, with the jobs routing already
                                merged in — replaces the one in your repo
```

---

## Step 1 — Install PHP-FPM and MySQL

Your VM doesn't have these yet (the main site deliberately uses neither).

```bash
sudo dnf module enable php:8.2 -y
sudo dnf install -y php-fpm php-cli php-mysqlnd php-mbstring php-gd php-xml php-curl php-opcache
sudo dnf install -y mysql-server
sudo systemctl enable --now php-fpm mysqld
sudo mysql_secure_installation
```

PHP-FPM's default pool runs as user `apache`, but your Nginx/docroot files
run as `nginx`. Fix the pool to match:
```bash
sudo sed -i 's/^user = apache/user = nginx/; s/^group = apache/group = nginx/' /etc/php-fpm.d/www.conf
sudo sed -i "s/^listen.acl_users.*/listen.acl_users = nginx/" /etc/php-fpm.d/www.conf 2>/dev/null
sudo systemctl restart php-fpm
```

### About your 1 GB of RAM

Your setup already runs Node (capped ~200MB via PM2) + Nginx + now PHP-FPM +
MySQL. That's tight on 1GB. Two changes worth making immediately:

```bash
# MySQL: cap InnoDB's memory instead of using the (often too-generous) default
sudo tee -a /etc/my.cnf.d/low-memory.cnf > /dev/null <<'EOF'
[mysqld]
innodb_buffer_pool_size = 128M
max_connections = 30
EOF
sudo systemctl restart mysqld

# PHP-FPM: fewer workers, since this site gets modest traffic
sudo sed -i 's/^pm.max_children.*/pm.max_children = 5/' /etc/php-fpm.d/www.conf
sudo sed -i 's/^pm = .*/pm = ondemand/' /etc/php-fpm.d/www.conf
sudo systemctl restart php-fpm
```
`pm = ondemand` means PHP-FPM workers spin down to zero when idle instead
of sitting in memory — worth it for a low-traffic site on a small VM.
Keep an eye on `free -m` after this goes live for a day or two.

---

## Step 2 — Create the database

```bash
sudo mysql -u root -p
```
```sql
CREATE DATABASE govtjobs CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'govtjobs_app'@'localhost' IDENTIFIED BY 'choose-a-strong-password-here';
GRANT ALL PRIVILEGES ON govtjobs.* TO 'govtjobs_app'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

---

## Step 3 — Add the files to your site

However you already deploy `index.html` (git pull, scp, whatever your
workflow is) — add these the same way:

```bash
# Jobs pages + API go in alongside index.html
cp -r webroot/* /var/www/rashtriyakhabar/

# Config goes OUTSIDE the docroot / OUTSIDE your git repo — never gets
# touched by a git pull, never at risk of being committed by accident
sudo mkdir -p /etc/govtjobs
sudo cp etc-govtjobs/*.php /etc/govtjobs/

# CLI scripts
sudo cp db/schema.sql create_admin.php fetch_jobs.php /root/
```

If your deployment is git-based (per your `setup.sh`'s auto-pull cron),
add `webroot/*` into the actual git repo at your next commit so future
`git pull`s keep it in sync automatically — `etc-govtjobs/` and the CLI
scripts still get placed manually as above, once.

---

## Step 4 — Configure and import

```bash
sudo nano /etc/govtjobs/config.php
```
Set `DB_PASS` to the password from Step 2. `SITE_URL` should already read
`https://rashtriyakhabar.in` — leave it unless that's wrong.

```bash
mysql -u govtjobs_app -p govtjobs < /root/schema.sql
```

Create your panel login:
```bash
cd /root
php create_admin.php youradminname
```

---

## Step 5 — Update your Nginx config

The `nginx-rashtriyakhabar.conf` in this folder is **your existing file**,
with the Govt Jobs routing merged in — your article-proxy `/api/` block,
SSL, gzip, security headers, everything else is untouched.

```bash
sudo cp nginx-rashtriyakhabar.conf /etc/nginx/conf.d/rashtriyakhabar.conf
sudo nginx -t
sudo systemctl reload nginx
```

If your deployment is git-based, commit this updated file too so it isn't
silently overwritten by the next auto-pull.

---

## Step 6 — SELinux

Oracle Linux ships SELinux enforcing by default. Nginx runs under the same
`httpd_t` policy domain as Apache would, so the same booleans apply:

```bash
sudo chown -R nginx:nginx /var/www/rashtriyakhabar/uploads
sudo setsebool -P httpd_can_network_connect_db 1
sudo semanage fcontext -a -t httpd_sys_rw_content_t "/var/www/rashtriyakhabar/uploads(/.*)?"
sudo restorecon -Rv /var/www/rashtriyakhabar/uploads
sudo chown -R nginx:nginx /etc/govtjobs
sudo chmod 640 /etc/govtjobs/*.php

# config.php stores PHP login sessions in /etc/govtjobs/sessions (not the
# system-wide session path — see the comment in config.php for why). PHP-FPM
# creates this folder itself on first run, but it still needs write
# permission AND the right SELinux label to be allowed to do so:
sudo mkdir -p /etc/govtjobs/sessions
sudo chown -R nginx:nginx /etc/govtjobs/sessions
sudo semanage fcontext -a -t httpd_sys_rw_content_t "/etc/govtjobs/sessions(/.*)?"
sudo restorecon -Rv /etc/govtjobs/sessions
```
(`semanage` missing? `sudo dnf install -y policycoreutils-python-utils`.)

---

## Step 7 — Test it

- `https://rashtriyakhabar.in/jobs` — empty listing (nothing published yet)
- `https://rashtriyakhabar.in/panel.php` — log in with your Step 4 account
- Create a test post, Publish, confirm it appears at `/jobs` and at its own
  `/jobs/<slug>/` link
- **Confirm your existing site still works exactly as before** — open a
  regular news article and check the reader still opens (this exercises
  your `/api/` article-proxy, which this whole setup was built to leave
  completely alone)
- Share a job post's link in WhatsApp to yourself — check the preview card

---

## Auto-fetch (optional)

Everything from before still applies — see the comments in `fetch_jobs.php`
and `/etc/govtjobs/config.php` for `MISTRAL_API_KEY` / `GEMINI_API_KEY` /
`FETCH_SOURCES`. Test with `php fetch_jobs.php --dry-run` before running it
for real or putting it on a cron schedule. It only ever creates **drafts** —
publishing is always your manual click in the panel.

One more RAM note: if you do turn on scheduled auto-fetch, avoid running it
in the same minute as your git auto-pull cron (per `setup.sh`) — running
`npm install` + a page-scraping run simultaneously on 1GB RAM is avoidable
contention. Offsetting by even 5 minutes is enough.

---

## Troubleshooting

**500 error on any jobs page** — `sudo tail -30 /var/log/nginx/error.log`.
Usually a wrong DB password in `/etc/govtjobs/config.php`, or the PHP-FPM
`user`/`group` mismatch from Step 1.

**502 Bad Gateway** — PHP-FPM isn't running, or the socket path in
`nginx-rashtriyakhabar.conf` (`/run/php-fpm/www.sock`) doesn't match your
actual PHP-FPM pool config. Check `sudo systemctl status php-fpm` and
`grep listen /etc/php-fpm.d/www.conf`.

**Your existing site's article reader broke** — it shouldn't have; the jobs
config only adds new `location` blocks and never modifies the `/api/`
block. If something's wrong, diff the shipped `nginx-rashtriyakhabar.conf`
against your previous version to see exactly what changed.

**Thumbnails 404 after upload** — re-run the `semanage`/`restorecon`
commands in Step 6.

**Logged out every time you refresh, or the panel says "Not logged in" the
moment you try to save/update a post** — PHP isn't able to persist session
data to disk, so every request effectively starts a brand-new, logged-out
session even though the login call itself said "ok". Almost always a
permissions/SELinux mismatch on the session folder from Step 6 (very common
after Step 1's `user = apache` → `user = nginx` change, since the *system's*
default session path is normally owned by `apache` only). To confirm:
```bash
sudo tail -20 /var/log/php-fpm/www-error.log   # or /var/log/nginx/error.log
```
Look for a line like `govtjobs: cannot write to session directory ...` —
that tells you exactly which folder and which user. Re-run the
`chown`/`semanage`/`restorecon` block for `/etc/govtjobs/sessions` above,
then try logging in again. You can also sanity-check the request itself in
your browser's DevTools → Network tab: open `jobs-api/login.php`'s response
headers and confirm a `Set-Cookie: govtjobs_admin=...` is present, then
check that the *next* request (e.g. `admin_list.php`) sends that same cookie
back in its `Cookie` request header — if it does but you still get "Not
logged in", the cookie is fine and it's specifically the server-side session
file that isn't being saved.

**`fetch_jobs.php` isn't creating any drafts, and/or you've hit Gemini's free
rate limit** — two separate things worth checking:
1. Run `php fetch_jobs.php --dry-run` (now free — see below) and read its
   output carefully. If it says "Could not reach ... — skipping this
   source" for every source, this VM's outbound network is blocked, or the
   source site is down/changed. If it reaches the pages but reports "Found 0
   candidate links" or "Could not find a usable title" for every link, the
   two example sources in `FETCH_SOURCES` have almost certainly changed
   their page structure since this fetcher's link/label patterns were
   written (see the warning comment at the top of `fetch_helpers.php` — this
   logic was written by reading the sites, not tested against them live).
   You'll need to adjust `fetch_helpers.php`'s patterns to match how those
   pages actually look today.
2. `--dry-run` now skips calling Mistral/Gemini entirely by default (nothing
   is saved either way, so there's nothing to gain from spending quota on a
   dry run) — pass `--dry-run --with-ai` only when you specifically want to
   preview AI-written output. This is what was draining the free Gemini
   quota: every dry-run attempt while troubleshooting called Gemini again
   for the same links, since a dry run never marks anything as "seen". A
   real (non-dry-run) run also now stops calling a provider for the rest of
   that run the moment it gets a 429 from it, instead of repeating the same
   failing call for every remaining link.
