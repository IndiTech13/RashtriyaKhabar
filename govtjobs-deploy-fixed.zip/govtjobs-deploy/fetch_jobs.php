<?php
/**
 * Checks each source in FETCH_SOURCES for new job postings, extracts facts,
 * generates an article, and saves it as a DRAFT for you to review in the panel.
 * Never publishes anything itself — that's always a manual click.
 *
 * Usage:
 *   php fetch_jobs.php --dry-run             # prints what it WOULD do, saves nothing,
 *                                             # AI generation skipped (no API calls made)
 *   php fetch_jobs.php --dry-run --with-ai   # same, but also calls Mistral/Gemini so you
 *                                             # can preview the AI-written article (uses quota)
 *   php fetch_jobs.php                       # actually creates draft posts
 *
 * Meant to run on a schedule — see README-DEPLOY.md "Auto-fetch" section for
 * the cron line. Safe to run as often as you like: already-seen source URLs
 * are skipped (unique index on posts.source_url), so nothing is duplicated.
 *
 * Designed to never die halfway through: a problem with one source or one
 * link is logged and skipped, not fatal to the rest of the run.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    die('This script can only be run from the command line.');
}

require_once '/etc/govtjobs/config.php';
require_once '/etc/govtjobs/helpers.php';
require_once '/etc/govtjobs/fetch_helpers.php';
require_once '/etc/govtjobs/ai_writer.php';

$dryRun  = in_array('--dry-run', $argv, true);
$withAi  = in_array('--with-ai', $argv, true);
// Dry runs default to skipping Mistral/Gemini entirely — a dry run is meant
// to be free and side-effect-free, and repeatedly testing extraction against
// a source (as the README suggests before trusting it unattended) previously
// meant repeatedly re-spending AI quota on the exact same candidate links,
// since nothing from a dry run is ever saved to mark them as "seen". Pass
// --with-ai alongside --dry-run if you specifically want to test AI output
// too (this WILL use quota).
$skipAi  = $dryRun && !$withAi;
if ($dryRun) {
    echo $withAi
        ? "Dry run with AI generation enabled (--with-ai) — this will call Mistral/Gemini.\n\n"
        : "Dry run: AI generation is skipped (add --with-ai to test it too). Nothing is saved either way.\n\n";
}

if (!MISTRAL_API_KEY && !GEMINI_API_KEY) {
    echo "Note: no MISTRAL_API_KEY or GEMINI_API_KEY set in config.php — articles will\n";
    echo "be written using the plain built-in template instead. That's fine, just FYI.\n\n";
}

if (!defined('FETCH_SOURCES') || !is_array(FETCH_SOURCES) || !FETCH_SOURCES) {
    fwrite(STDERR, "FETCH_SOURCES is empty or not set in config.php — nothing to do.\n");
    exit(1);
}

try {
    $pdo = db();
} catch (Throwable $e) {
    fwrite(STDERR, "Could not connect to the database: " . $e->getMessage() . "\n");
    exit(1);
}

$totalNew = 0;
$totalErrors = 0;

foreach (FETCH_SOURCES as $source) {
    $name = $source['name'] ?? '(unnamed source)';
    $listingUrl = $source['listing_url'] ?? null;
    echo "== $name ==\n";

    if (!$listingUrl) {
        echo "  Skipping — no listing_url configured for this source.\n\n";
        continue;
    }

    $listingHtml = fetch_url($listingUrl);
    if (!$listingHtml) {
        echo "  Could not reach $listingUrl — skipping this source.\n\n";
        $totalErrors++;
        continue;
    }

    try {
        $links = extract_listing_links($listingHtml, $listingUrl);
    } catch (Throwable $e) {
        echo "  Could not read the listing page (" . $e->getMessage() . ") — skipping this source.\n\n";
        $totalErrors++;
        continue;
    }
    echo "  Found " . count($links) . " candidate links on the listing page.\n";

    foreach ($links as $link) {
        try {
            $result = process_one_listing($pdo, $link, $source, $name, $dryRun, $skipAi);
            if ($result === 'created') $totalNew++;
        } catch (Throwable $e) {
            echo "     Unexpected error on this link, skipping it: " . $e->getMessage() . "\n\n";
            error_log('fetch_jobs.php error on ' . $link['url'] . ': ' . $e->getMessage());
            $totalErrors++;
        }
    }
    echo "\n";
}

echo $dryRun
    ? "Dry run complete. Nothing was saved.\n"
    : "Done. $totalNew new draft(s) waiting for your review in panel.php.\n";
if ($totalErrors) {
    echo "($totalErrors item(s) skipped due to errors — see above, or check the PHP error log.)\n";
}

/**
 * Handles exactly one candidate link: skip-if-seen, fetch, extract, write,
 * save. Returns 'created', 'skipped', or 'dry-run'.
 */
function process_one_listing(PDO $pdo, array $link, array $source, string $sourceName, bool $dryRun, bool $skipAi = false): string {
    // Skip if we've already created a draft/post from this exact URL before.
    $stmt = $pdo->prepare('SELECT id FROM posts WHERE source_url = ?');
    $stmt->execute([$link['url']]);
    if ($stmt->fetch()) return 'skipped';

    echo "  -> New: {$link['title']}\n     {$link['url']}\n";

    $postHtml = fetch_url($link['url']);
    if (!$postHtml) {
        echo "     Could not fetch this page — skipping.\n\n";
        return 'skipped';
    }

    $facts = extract_facts($postHtml, $link['title'], $link['url'], $link['url']);

    // A page that yielded literally no usable title is not something we can
    // sensibly save — title is the one field with no fallback.
    $title = trim((string)($facts['title'] ?? ''));
    if ($title === '') {
        echo "     Could not find a usable title on this page — skipping.\n\n";
        return 'skipped';
    }
    // DB column is VARCHAR(300); truncate defensively rather than let a
    // freak long title fail the insert outright.
    if (mb_strlen($title) > 300) $title = mb_substr($title, 0, 297) . '…';
    $facts['title'] = $title;

    $facts['start_date'] = normalize_date($facts['start_date'] ?? null);
    $facts['last_date']  = normalize_date($facts['last_date'] ?? null);
    $facts['exam_date']  = normalize_date($facts['exam_date'] ?? null);

    // Only keep well-formed http(s) links — anything else (a stray "#",
    // a javascript: link that slipped through, etc.) is dropped rather
    // than saved into a link button that would go nowhere useful.
    $facts['official_link'] = valid_url_or_null($facts['official_link'] ?? null);
    $facts['apply_link']    = valid_url_or_null($facts['apply_link'] ?? null);
    $facts['extra_links']   = array_values(array_filter($facts['extra_links'] ?? [], function ($l) {
        return !empty($l['label']) && !empty($l['url']) && filter_var($l['url'], FILTER_VALIDATE_URL);
    }));

    $article = generate_article($facts, $skipAi);
    if (!$skipAi && $article['method'] !== 'template') {
        // Be a good citizen of the free tier: a backlog of many new links in
        // one run would otherwise fire off calls back-to-back and trip a
        // per-minute rate limit that a small gap easily avoids.
        usleep(1200000); // 1.2s
    }
    $linkCount = (int)!empty($facts['official_link']) + (int)!empty($facts['apply_link']) + count($facts['extra_links']);
    echo "     Facts found: vacancy=" . ($facts['total_vacancy'] ?? '—')
       . ", last_date=" . ($facts['last_date'] ?? '—')
       . ", links=$linkCount\n";
    echo "     Article written by: {$article['method']}\n";

    if ($dryRun) {
        echo "     [dry run — not saved]\n\n";
        return 'dry-run';
    }

    // Defense in depth: sanitize the generated body the same way manually
    // written posts are sanitized in api/save.php, even though the AI
    // prompt and the template both already avoid producing anything unsafe.
    $body = clean_body_html($article['body']);

    $slug = make_slug($facts['title']);
    $extraLinksJson = $facts['extra_links']
        ? json_encode($facts['extra_links'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        : null;
    $orgName = !empty($facts['org_name']) ? mb_substr(trim($facts['org_name']), 0, 200) : null;

    $ins = $pdo->prepare(
        'INSERT INTO posts (slug, title, org_name, body, official_link, apply_link, extra_links,
                             start_date, last_date, exam_date, status, source_name, source_url)
         VALUES (?,?,?,?,?,?,?,?,?,?,"draft",?,?)'
    );
    try {
        $ins->execute([
            $slug, $facts['title'], $orgName, $body,
            $facts['official_link'], $facts['apply_link'], $extraLinksJson,
            $facts['start_date'], $facts['last_date'], $facts['exam_date'],
            $sourceName, $link['url'],
        ]);
    } catch (PDOException $e) {
        // Most likely cause: source_url collided with one written by a
        // concurrent run — treat as already-seen rather than a hard failure.
        if (str_contains($e->getMessage(), 'uniq_source_url') || str_contains($e->getMessage(), 'Duplicate entry')) {
            echo "     Already saved (race with another run) — skipping.\n\n";
            return 'skipped';
        }
        throw $e;
    }

    echo "     Saved as draft (id " . $pdo->lastInsertId() . "). Review it in panel.php.\n\n";
    return 'created';
}

function valid_url_or_null(?string $url): ?string {
    if (!$url) return null;
    return filter_var($url, FILTER_VALIDATE_URL) ? $url : null;
}
