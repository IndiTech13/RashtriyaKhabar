<?php
/**
 * Shared helpers for the Govt Jobs panel + API. Included after config.php.
 */

/** Send a JSON response and stop execution. */
function json_out($data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Require an active admin session for API endpoints. Halts with 401 JSON if absent. */
function require_login_api(): void {
    if (empty($_SESSION['admin_id'])) {
        json_out(['ok' => false, 'error' => 'Not logged in.'], 401);
    }
}

/** Require an active admin session for full-page endpoints (panel.php). Redirects instead of JSON. */
function require_login_page(): void {
    if (empty($_SESSION['admin_id'])) {
        header('Location: panel.php');
        exit;
    }
}

/** Turn a title into a URL-safe, unique, lowercase slug. Appends -2, -3... on collision. */
function make_slug(string $title, ?int $excludeId = null): string {
    $base = strtolower(trim($title));
    // Keep Devanagari + Latin letters/numbers, turn everything else into a hyphen.
    $base = preg_replace('/[^\p{L}\p{N}]+/u', '-', $base);
    $base = trim($base, '-');
    if ($base === '') $base = 'post';
    if (mb_strlen($base) > 180) $base = mb_substr($base, 0, 180);

    $slug = $base;
    $n = 2;
    $pdo = db();
    while (true) {
        $sql = 'SELECT id FROM posts WHERE slug = ?' . ($excludeId ? ' AND id != ?' : '');
        $stmt = $pdo->prepare($sql);
        $excludeId ? $stmt->execute([$slug, $excludeId]) : $stmt->execute([$slug]);
        if (!$stmt->fetch()) return $slug;
        $slug = $base . '-' . $n;
        $n++;
    }
}

/** Very small HTML sanitizer for the rich-text body: strips <script>/<style> and on* attributes. */
function clean_body_html(string $html): string {
    $html = preg_replace('#<script\b[^>]*>.*?</script>#is', '', $html);
    $html = preg_replace('#<style\b[^>]*>.*?</style>#is', '', $html);
    $html = preg_replace('#\son[a-z]+\s*=\s*"[^"]*"#i', '', $html);
    $html = preg_replace("#\son[a-z]+\s*=\s*'[^']*'#i", '', $html);
    $html = preg_replace('#\son[a-z]+\s*=\s*[^\s>]+#i', '', $html);
    $html = preg_replace('#(href|src)\s*=\s*"\s*javascript:[^"]*"#i', '$1="#"', $html);
    return $html;
}

/**
 * Parse the extra_links JSON column into a clean array of ['label'=>..,'url'=>..].
 * Silently drops anything malformed rather than erroring — this only feeds display code.
 */
function parse_extra_links(?string $json): array {
    if (!$json) return [];
    $data = json_decode($json, true);
    if (!is_array($data)) return [];
    $out = [];
    foreach ($data as $item) {
        if (!empty($item['label']) && !empty($item['url']) && filter_var($item['url'], FILTER_VALIDATE_URL)) {
            $out[] = ['label' => (string)$item['label'], 'url' => (string)$item['url']];
        }
    }
    return $out;
}

/** Build the extra_links JSON column value from parallel arrays posted by the panel form. */
function build_extra_links_json(array $labels, array $urls): ?string {
    $out = [];
    foreach ($labels as $i => $label) {
        $label = trim($label);
        $url = trim($urls[$i] ?? '');
        if ($label !== '' && $url !== '' && filter_var($url, FILTER_VALIDATE_URL)) {
            $out[] = ['label' => $label, 'url' => $url];
        }
    }
    return $out ? json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
}
