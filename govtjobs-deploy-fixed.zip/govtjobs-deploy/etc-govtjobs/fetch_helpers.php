<?php
/**
 * Fetches public listing + post pages from the sources in FETCH_SOURCES and
 * pulls out bare facts via text-pattern matching (not CSS selectors, so it
 * keeps working even if a site's visual design changes — the label text
 * itself, e.g. "Total No. of the Posts:", is far more stable than markup).
 *
 * IMPORTANT: this was written by reading real pages from both sites, but
 * could not be tested against them live from the environment that built it
 * (no outbound network access to arbitrary sites). Run fetch_jobs.php with
 * --dry-run first and read the output before trusting it unattended — see
 * README-DEPLOY.md "Auto-fetch" section.
 */

function fetch_url(string $url): ?string {
    // Basic sanity check before we even try — malformed URLs from a listing
    // page (e.g. "javascript:void(0)" or a mailto: link) should never reach curl.
    if (!preg_match('#^https?://#i', $url)) return null;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 3,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; RashtriyaKhabarJobsBot/1.0; +https://rashtriyakhabar.in)',
        CURLOPT_HTTPHEADER     => ['Accept: text/html'],
        // Refuse to download something absurd (a mis-linked video/zip etc.) —
        // real job-notice pages are a few hundred KB at most.
        CURLOPT_BUFFERSIZE     => 16384,
        CURLOPT_NOPROGRESS     => false,
        CURLOPT_PROGRESSFUNCTION => function ($res, $expectDl, $actualDl) {
            return $actualDl > 8 * 1024 * 1024 ? 1 : 0; // abort past 8MB
        },
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($err || !$body || $code < 200 || $code >= 300) {
        error_log("fetch_url failed ($code): $url" . ($err ? " — $err" : ''));
        return null;
    }
    return $body;
}

/** Load HTML into a DOMDocument without PHP dumping warnings for malformed markup. */
function load_html(string $html): DOMDocument {
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html);
    libxml_clear_errors();
    return $dom;
}

/**
 * Finds candidate "new post" links on a listing page: anchors inside the
 * main content whose text looks like a job-posting title (long-ish, not a
 * nav/menu item) and whose href is on the same domain.
 * Returns [[title, url], ...] deduplicated by url, newest-appearing first.
 */
function extract_listing_links(string $html, string $baseUrl): array {
    $dom = load_html($html);
    $xpath = new DOMXPath($dom);
    $baseHost = parse_url($baseUrl, PHP_URL_HOST) ?: '';
    $skipWords = ['home', 'contact', 'privacy', 'disclaimer', 'view more', 'search', 'menu', 'join now', 'read more'];
    $seen = [];
    $out = [];
    foreach ($xpath->query('//a[@href]') as $a) {
        $href = trim($a->getAttribute('href'));
        $text = trim(preg_replace('/\s+/', ' ', $a->textContent));
        if ($text === '' || mb_strlen($text) < 12) continue;
        if (in_array(mb_strtolower($text), $skipWords)) continue;
        if (preg_match('/^(javascript|mailto|tel):/i', $href)) continue;
        // Skip obvious non-post links (category/tag/author archive pages, pagination)
        if (preg_match('#/(category|tag|author|page)/#i', $href)) continue;

        $resolved = resolve_url($href, $baseUrl);
        if (!$resolved) continue;
        if ($baseHost && parse_url($resolved, PHP_URL_HOST) !== $baseHost) continue; // off-site link, skip
        if (isset($seen[$resolved])) continue;
        $seen[$resolved] = true;
        $out[] = ['title' => $text, 'url' => $resolved];
    }
    return $out;
}

/** Plain visible text of the page body, whitespace-collapsed — used for label pattern-matching. */
function extract_plain_text(string $html): string {
    $dom = load_html($html);
    $xpath = new DOMXPath($dom);
    foreach ($xpath->query('//script|//style|//nav|//footer') as $node) {
        $node->parentNode->removeChild($node);
    }
    $text = $dom->textContent;
    return trim(preg_replace('/[ \t]+/', ' ', preg_replace('/\n{2,}/', "\n", $text)));
}

/** All links on the page with non-trivial anchor text, for label-based classification. */
function extract_all_links(string $html, string $baseUrl): array {
    $dom = load_html($html);
    $xpath = new DOMXPath($dom);
    $out = [];
    foreach ($xpath->query('//a[@href]') as $a) {
        $text = trim(preg_replace('/\s+/', ' ', $a->textContent));
        $href = trim($a->getAttribute('href'));
        if ($text === '' || $href === '' || $href === '#') continue;
        if (preg_match('/^(javascript|mailto|tel):/i', $href)) continue;
        $resolved = resolve_url($href, $baseUrl);
        if ($resolved) $out[] = ['text' => $text, 'url' => $resolved];
    }
    return $out;
}

/** Resolves a possibly-relative href against a base URL. Returns null if it can't make sense of it. */
function resolve_url(string $href, string $baseUrl): ?string {
    if (preg_match('#^https?://#i', $href)) return $href;          // already absolute
    if (str_starts_with($href, '//')) return 'https:' . $href;     // protocol-relative
    $base = parse_url($baseUrl);
    if (empty($base['host'])) return null;
    $origin = ($base['scheme'] ?? 'https') . '://' . $base['host'] . (isset($base['port']) ? ':' . $base['port'] : '');
    if (str_starts_with($href, '/')) return $origin . $href;       // root-relative

    // Plain relative path ("foo.pdf", "../foo.pdf") — resolve against the
    // base URL's own directory, collapsing any "../" segments.
    $basePath = $base['path'] ?? '/';
    $baseDir = str_ends_with($basePath, '/') ? $basePath : (dirname($basePath) . '/');
    $combined = $baseDir . $href;
    $parts = [];
    foreach (explode('/', $combined) as $seg) {
        if ($seg === '.' || $seg === '') continue;
        if ($seg === '..') { array_pop($parts); continue; }
        $parts[] = $seg;
    }
    return $origin . '/' . implode('/', $parts);
}

/** Regex-extract one labeled fact, e.g. "Total No. of the Posts: 5500" -> "5500". */
function match_after_label(string $text, array $labelPatterns, int $maxLen = 160): ?string {
    foreach ($labelPatterns as $label) {
        if (preg_match('/' . preg_quote($label, '/') . '\s*[:\-]?\s*(.+?)(?:\n|$)/iu', $text, $m)) {
            $val = trim($m[1], " \t\n\r\0\x0B.");
            // Some sites put extra detail in parens right after the label before the
            // real colon, e.g. "Age Limit (17.5 to 22 years): Born not earlier...".
            // Strip a leading "(...): " so it doesn't leak into the captured value twice.
            $val = preg_replace('/^\([^)]*\)\s*:?\s*/u', '', $val);
            $val = mb_substr($val, 0, $maxLen);
            if ($val !== '') return $val;
        }
    }
    return null;
}

/** Pulls the page's own <h1> (preferred) or <title> tag — usually a fuller, more
 *  accurate headline than whatever short link text pointed to it from a listing page. */
function extract_page_title(string $html, string $fallback): string {
    $dom = load_html($html);
    $xpath = new DOMXPath($dom);
    $h1 = $xpath->query('//h1')->item(0);
    if ($h1 && trim($h1->textContent) !== '') {
        return trim(preg_replace('/\s+/', ' ', $h1->textContent));
    }
    $titleTag = $xpath->query('//title')->item(0);
    if ($titleTag && trim($titleTag->textContent) !== '') {
        // Strip common "| Site Name" suffixes some themes add to <title>.
        $t = trim(preg_replace('/\s+/', ' ', $titleTag->textContent));
        $t = preg_replace('/\s*[\|\-–]\s*[^|\-–]{0,40}$/u', '', $t);
        return $t !== '' ? $t : $fallback;
    }
    return $fallback;
}

/**
 * Finds an element (heading/bold/paragraph) whose text contains $labelText,
 * then returns the next <ul>/<ol> that appears after it in the document,
 * as a flat array of item strings. Used for "Selection Process", "How to
 * Apply" style bullet lists that are genuinely just enumerated facts/steps.
 */
function extract_list_after_label(string $html, string $labelText): array {
    $dom = load_html($html);
    $xpath = new DOMXPath($dom);
    $marker = find_label_node($xpath, $labelText);
    if (!$marker) return [];

    $list = find_following(
        $xpath, $marker, "self::ul or self::ol",
        "self::h1 or self::h2 or self::h3 or self::h4 or self::h5 or self::h6"
    );
    if (!$list) return [];

    $items = [];
    foreach ($xpath->query('.//li', $list) as $li) {
        $t = trim(preg_replace('/\s+/', ' ', $li->textContent));
        if ($t !== '') $items[] = $t;
    }
    return $items;
}

/**
 * Same idea but for a <table> after a label (e.g. "Salary and Benefits",
 * "Important Dates") — returns rows as arrays of cell text.
 */
function extract_table_after_label(string $html, string $labelText): array {
    $dom = load_html($html);
    $xpath = new DOMXPath($dom);
    $marker = find_label_node($xpath, $labelText);
    if (!$marker) return [];

    $table = find_following(
        $xpath, $marker, "self::table",
        "self::h1 or self::h2 or self::h3 or self::h4 or self::h5 or self::h6"
    );
    if (!$table) return [];

    $rows = [];
    foreach ($xpath->query('.//tr', $table) as $tr) {
        $cells = [];
        foreach ($xpath->query('.//td|.//th', $tr) as $cell) {
            $cells[] = trim(preg_replace('/\s+/', ' ', $cell->textContent));
        }
        if ($cells) $rows[] = $cells;
    }
    return $rows;
}

/** Finds the first element whose direct text contains $labelText (case-insensitive). */
function find_label_node(DOMXPath $xpath, string $labelText): ?DOMNode {
    $query = sprintf(
        '//*[self::strong or self::b or self::h1 or self::h2 or self::h3 or self::h4 or self::h5 or self::p]'
        . '[contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "%s")]',
        strtolower($labelText)
    );
    $nodes = @$xpath->query($query);
    return ($nodes && $nodes->length) ? $nodes->item(0) : null;
}

/**
 * Walks forward through the document from $marker (in document order) and
 * returns the first element matching $wantXPath, stopping early (returns
 * null) if it hits $stopXPath first — so we don't accidentally grab a list
 * or table that actually belongs to the NEXT section.
 */
function find_following(DOMXPath $xpath, DOMNode $marker, string $wantXPath, string $stopXPath): ?DOMNode {
    $following = $xpath->query('following::*', $marker);
    foreach ($following as $node) {
        if (matches_self($xpath, $node, $wantXPath)) {
            return $node;
        }
        if (matches_self($xpath, $node, $stopXPath)) {
            return null; // hit the next heading before finding what we wanted
        }
    }
    return null;
}
function matches_self(DOMXPath $xpath, DOMNode $node, string $selfXPath): bool {
    $tag = strtolower($node->nodeName);
    return (bool)preg_match('/self::' . preg_quote($tag, '/') . '\b/', $selfXPath);
}

/**
 * Pulls the fact set out of a single job-posting page's HTML.
 * Returns an array ready to hand to generate_article() plus a 'links' list.
 */
function extract_facts(string $html, string $title, string $sourceUrl, string $baseUrl): array {
    $title = extract_page_title($html, $title);
    $text = extract_plain_text($html);

    $facts = [
        'title'          => $title,
        'org_name'       => match_after_label($text, ['Recruitment Board', 'Organisation', 'Organization']),
        'total_vacancy'  => match_after_label($text, ['Total No. of the Posts', 'Total No of Posts', 'Total Post', 'Total Vacancy', 'Total Vacancies'], 20),
        'qualification'  => match_after_label($text, ['Qualification'], 200),
        'age_limit'      => match_after_label($text, ['Age Limit'], 150),
        'fee'            => match_after_label($text, ['Fees', 'Fee', 'Application Fee'], 200),
        'start_date'     => match_after_label($text, ['Start From', 'Application Begin', 'Start Date', 'Online Registration Start'], 20),
        'last_date'      => match_after_label($text, ['Closure Date', 'Last Date', 'Closing Date', 'Application Last Date'], 20),
        'exam_date'      => match_after_label($text, ['Exam Date', 'Date of Exam', 'Date of PMT', 'Written Exam Date'], 30),
    ];

    // These are enumerated criteria (steps, physical standards, a dates table) —
    // all facts set by the notice itself, not the source site's prose — so we
    // pull them as structured lists/tables rather than skipping them.
    $facts['selection_process'] = extract_list_after_label($html, 'Selection Process');
    $facts['physical_eligibility'] = extract_list_after_label($html, 'Physical Eligibility');
    $facts['important_dates_table'] = extract_table_after_label($html, 'Important Dates');
    $facts['salary_table'] = extract_table_after_label($html, 'Salary');

    // Indian govt notices are very often extended/re-opened after the original
    // dates — when that shows up, it supersedes the original start/last date.
    // (Found by testing against a real notice during development — the
    // original dates alone would have been wrong here.)
    $reopen = match_after_label($text, ['Re-Open Date', 'Reopen Date', 'Extended Date', 'Re-scheduled Date'], 60);
    if ($reopen && preg_match('/(\d{1,2}[.\-\/]\d{1,2}[.\-\/]\d{4}).{0,10}?(?:to|-|–)\s*(\d{1,2}[.\-\/]\d{1,2}[.\-\/]\d{4})/', $reopen, $m)) {
        $facts['start_date'] = $m[1];
        $facts['last_date']  = $m[2];
        $facts['dates_were_extended'] = true;
    }

    // Classify links by their visible label text into the buttons our post page shows.
    $officialLink = null; $applyLink = null; $extraLinks = [];
    $labelRules = [
        'apply_link'    => ['apply online', 'apply now', 'click here to apply'],
        'official_link' => ['official detail', 'official notification', 'notification pdf', 'gazette notice', 'download notification'],
    ];
    foreach (extract_all_links($html, $baseUrl) as $link) {
        $lower = mb_strtolower($link['text']);
        if (!$applyLink && str_contains_any($lower, $labelRules['apply_link'])) { $applyLink = $link['url']; continue; }
        if (!$officialLink && str_contains_any($lower, $labelRules['official_link'])) { $officialLink = $link['url']; continue; }
        if (str_contains_any($lower, ['admit card', 'download admit'])) { $extraLinks[] = ['label' => 'Admit Card Download', 'url' => $link['url']]; }
        elseif (str_contains_any($lower, ['result', 'candidate list', 'cutoff'])) { $extraLinks[] = ['label' => 'Result', 'url' => $link['url']]; }
        elseif (str_contains_any($lower, ['syllabus'])) { $extraLinks[] = ['label' => 'Syllabus', 'url' => $link['url']]; }
        elseif (str_contains_any($lower, ['answer key'])) { $extraLinks[] = ['label' => 'Answer Key', 'url' => $link['url']]; }
    }
    // De-dupe extra links by url, cap at 6 so the sidebar doesn't get overwhelming.
    $extraLinks = array_values(array_reduce($extraLinks, function($carry, $item) {
        $carry[$item['url']] = $item; return $carry;
    }, []));
    $extraLinks = array_slice($extraLinks, 0, 6);

    $facts['official_link'] = $officialLink;
    $facts['apply_link']    = $applyLink;
    $facts['extra_links']   = $extraLinks;
    $facts['source_url']    = $sourceUrl;

    return $facts;
}

function str_contains_any(string $haystack, array $needles): bool {
    foreach ($needles as $n) { if (str_contains($haystack, $n)) return true; }
    return false;
}

/** Best-effort DD.MM.YYYY / DD-MM-YYYY -> Y-m-d. Returns null if it doesn't look like a date. */
function normalize_date(?string $raw): ?string {
    if (!$raw) return null;
    if (preg_match('/(\d{1,2})[.\-\/](\d{1,2})[.\-\/](\d{4})/', $raw, $m)) {
        return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
    }
    return null; // leave blank rather than guess wrong — admin can fill it in during review
}
