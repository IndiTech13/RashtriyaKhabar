<?php
/**
 * Rashtriya Khabar — Govt Jobs section
 * Database + session configuration.
 *
 * This file is deliberately kept OUTSIDE the web root (/var/www/rashtriyakhabar) so it
 * can never be downloaded directly by a browser, no matter how Apache is
 * configured. The webroot PHP files pull it in with an absolute require_once.
 *
 * >>> EDIT THE FOUR VALUES BELOW to match the database you create in
 *     STEP 4 of README-DEPLOY.md, then leave this file alone. <<<
 */

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'govtjobs');
define('DB_USER', 'govtjobs_app');
define('DB_PASS', 'CHANGE_ME_STRONG_PASSWORD');

// Absolute path to the uploads folder inside the webroot (thumbnails land here).
define('UPLOAD_DIR', '/var/www/rashtriyakhabar/uploads/thumbs');
// Public URL path that maps to UPLOAD_DIR above.
define('UPLOAD_URL', '/uploads/thumbs');

// Used to build canonical links + Open Graph tags on post.php.
// Set this to your real site URL (no trailing slash).
define('SITE_URL', 'https://rashtriyakhabar.in');
define('SITE_NAME', 'Rashtriya Khabar');

// ---- Auto-fetch feature (optional) ----
// Leave these blank to keep the fetcher fully disabled — nothing runs without
// a key. Get free keys (no card needed) from:
//   Mistral: console.mistral.ai -> API Keys
//   Gemini:  aistudio.google.com/apikey
define('MISTRAL_API_KEY', '');
define('GEMINI_API_KEY', '');

// Government job listing sources the fetcher checks for new postings.
// Add/remove entries here — each needs a listing page (where new post links
// appear) and a short name shown only to you in the panel.
define('FETCH_SOURCES', [
    ['name' => 'speedjob.in',        'listing_url' => 'https://www.speedjob.in/latest-job/'],
    ['name' => 'sarkariresult.com.cm', 'listing_url' => 'https://sarkariresult.com.cm/latest-jobs/'],
]);

// ---- Below this line you shouldn't need to change anything ----

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

// Session must be started before any output. Cookie is locked to HTTPS +
// same-site once you're serving over TLS (recommended — see README step 7).
if (session_status() === PHP_SESSION_NONE) {

    // ---- Session storage location ----
    // Deliberately NOT using PHP's system-wide default session path
    // (usually /var/lib/php/session). On RHEL/Oracle Linux that directory
    // is normally only writable by the 'apache' user — but README-DEPLOY.md
    // Step 1 changes the PHP-FPM pool to run as 'nginx' to match this site's
    // webserver. After that change, PHP-FPM can no longer write session
    // files at all: session_start() doesn't error, it just silently fails
    // to persist anything, so $_SESSION looks fine for the rest of the
    // request that set it and is then completely empty on the very next
    // request (symptoms: "logged out on every refresh", save/update actions
    // suddenly saying "Not logged in").
    //
    // Storing sessions in our own folder next to config.php sidesteps that
    // entirely: whichever user PHP-FPM actually runs as is the same user
    // that creates this folder, so it's always writable by the process that
    // needs it, regardless of how the system-wide session path is owned.
    $sessionDir = __DIR__ . '/sessions';
    if (!is_dir($sessionDir)) {
        @mkdir($sessionDir, 0700, true);
    }
    if (is_dir($sessionDir) && is_writable($sessionDir)) {
        session_save_path($sessionDir);
    } else {
        // Couldn't create/write our own folder either — fall back to the
        // system default and log loudly, rather than fail silently.
        error_log(
            'govtjobs: cannot write to session directory ' . $sessionDir .
            ' (running as ' . (function_exists('posix_getpwuid') && function_exists('posix_geteuid')
                ? (posix_getpwuid(posix_geteuid())['name'] ?? 'unknown') : 'unknown') .
            '). Sessions will not persist — run: sudo chown -R <php-fpm-user>:<php-fpm-group> ' . $sessionDir
        );
    }

    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('govtjobs_admin');
    session_start();
}
