<?php
/**
 * Turns extracted facts into an original article, trying providers in order:
 *   1. Mistral (free tier)
 *   2. Gemini (free tier)
 *   3. Plain template (no AI, always works)
 *
 * Every path only ever sees FACTS (numbers, dates, labels, list/table items
 * that are themselves just enumerated criteria) — never another site's
 * sentences — so there's nothing for any of the three paths to copy.
 */

function build_facts_prompt(array $facts): string {
    $lines = [];
    $lines[] = "Job title: " . $facts['title'];
    if (!empty($facts['org_name']))     $lines[] = "Organisation: " . $facts['org_name'];
    if (!empty($facts['total_vacancy']) && !is_placeholder($facts['total_vacancy']))
        $lines[] = "Total vacancies: " . $facts['total_vacancy'];
    if (!empty($facts['qualification']))$lines[] = "Qualification required: " . $facts['qualification'];
    if (!empty($facts['age_limit']))    $lines[] = "Age limit: " . $facts['age_limit'];
    if (!empty($facts['fee']))          $lines[] = "Application fee: " . $facts['fee'];
    if (!empty($facts['start_date']))   $lines[] = "Application start date: " . $facts['start_date'];
    if (!empty($facts['last_date']))    $lines[] = "Application last date: " . $facts['last_date'];
    if (!empty($facts['exam_date']))    $lines[] = "Exam date: " . $facts['exam_date'];

    if (!empty($facts['selection_process'])) {
        $lines[] = "Selection process steps: " . implode(' -> ', $facts['selection_process']);
    }
    if (!empty($facts['physical_eligibility'])) {
        $lines[] = "Physical eligibility criteria: " . implode('; ', $facts['physical_eligibility']);
    }
    if (!empty($facts['important_dates_table'])) {
        $rows = array_map(fn($r) => implode(': ', array_slice($r, 0, 2)), $facts['important_dates_table']);
        $lines[] = "Full schedule: " . implode(' | ', $rows);
    }
    if (!empty($facts['salary_table'])) {
        $rows = array_map(fn($r) => implode(' - ', $r), $facts['salary_table']);
        $lines[] = "Salary by year: " . implode(' | ', $rows);
    }
    return implode("\n", $lines);
}

function is_placeholder(string $val): bool {
    return (bool)preg_match('/^\s*(not\s*given|n\.?a\.?|tbd|to\s*be\s*announced)\s*$/i', $val);
}

const ARTICLE_SYSTEM_PROMPT = <<<'EOT'
You write clear, complete, original news-style articles about Indian government
job notifications for a news website's Govt Jobs section. You will be given a
list of bare facts, dates, and enumerated criteria (steps, physical standards,
a schedule, a salary table) with no source article text attached.

Rules:
- Write a genuinely complete article covering every fact given: the
  announcement itself, qualification, age limit, fee, the full schedule, the
  selection process steps, physical eligibility criteria, and salary if given.
- Never invent facts that were not provided. If something is missing, skip it.
- Use your own original sentences and structure throughout — do not mimic a
  generic "govt job blog" template phrasing.
- Plain HTML only: <p> for paragraphs, <h3> for section breaks, <ul><li> for
  the selection process / physical eligibility lists, <table> for the
  schedule/salary if there are 3+ rows. No inline styles, no markdown.
- Neutral, factual tone — no exclamation marks, no promotional language.
- Output ONLY the HTML, nothing else (no preamble, no explanation).
EOT;

/** Models occasionally wrap output in ```html ... ``` despite instructions not to. Strip it if present. */
function strip_code_fence(string $text): string {
    $text = preg_replace('/^```[a-z]*\s*/i', '', trim($text));
    $text = preg_replace('/```\s*$/', '', $text);
    return trim($text);
}

/**
 * Remembers, for the lifetime of this PHP process only, which providers have
 * already returned a 429 (rate limit) response. Once a provider is blocked,
 * every remaining link in this run skips straight past it instead of making
 * a call that's certain to fail — this is what was burning through the free
 * Gemini quota: a run with many candidate links would keep calling Gemini
 * for every single one even after the first 429, one call per link.
 * Call with $block=true to mark a provider blocked; omit to just check.
 */
function ai_rate_limited(string $provider, bool $block = false): bool {
    static $blocked = [];
    if ($block) {
        $blocked[$provider] = true;
        fwrite(STDERR, "     [!] $provider returned a rate-limit response — skipping it for the rest of this run.\n");
    }
    return !empty($blocked[$provider]);
}

function call_mistral(string $factsText): ?string {
    if (!MISTRAL_API_KEY) return null;
    if (ai_rate_limited('mistral')) return null;
    $payload = [
        'model' => 'mistral-small-latest',
        'messages' => [
            ['role' => 'system', 'content' => ARTICLE_SYSTEM_PROMPT],
            ['role' => 'user', 'content' => $factsText],
        ],
        'temperature' => 0.3,
        'max_tokens' => 900,
    ];
    $code = null;
    $resp = http_post_json('https://api.mistral.ai/v1/chat/completions', $payload, [
        'Authorization: Bearer ' . MISTRAL_API_KEY,
    ], $code);
    if ($code === 429) { ai_rate_limited('mistral', true); return null; }
    if (!$resp) return null;
    $data = json_decode($resp, true);
    if (!is_array($data)) { error_log('Mistral: non-JSON response'); return null; }
    $text = $data['choices'][0]['message']['content'] ?? null;
    return (is_string($text) && trim($text) !== '') ? strip_code_fence($text) : null;
}

function call_gemini(string $factsText): ?string {
    if (!GEMINI_API_KEY) return null;
    if (ai_rate_limited('gemini')) return null;
    $payload = [
        'contents' => [
            ['parts' => [['text' => ARTICLE_SYSTEM_PROMPT . "\n\n" . $factsText]]],
        ],
        'generationConfig' => ['temperature' => 0.3, 'maxOutputTokens' => 900],
    ];
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';
    $code = null;
    $resp = http_post_json($url, $payload, [
        'x-goog-api-key: ' . GEMINI_API_KEY,
    ], $code);
    if ($code === 429) { ai_rate_limited('gemini', true); return null; }
    if (!$resp) return null;
    $data = json_decode($resp, true);
    if (!is_array($data)) { error_log('Gemini: non-JSON response'); return null; }
    $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? null;
    return (is_string($text) && trim($text) !== '') ? strip_code_fence($text) : null;
}

/** No-AI fallback. Covers the same facts as the AI prompt, in fixed (but
 *  complete) sentence/list/table shapes — original wording, not copied. */
function write_article_template(array $facts): string {
    $org = $facts['org_name'] ?? 'The department';
    $titleText = trim((string)($facts['title'] ?? '')) ?: 'this position';
    $html = '<p>' . htmlspecialchars($org) . ' has announced ' . htmlspecialchars($titleText) . '.';
    if (!empty($facts['last_date'])) {
        $html .= !empty($facts['start_date'])
            ? ' Applications are open from ' . htmlspecialchars($facts['start_date']) . ' to ' . htmlspecialchars($facts['last_date']) . '.'
            : ' Last date to apply: ' . htmlspecialchars($facts['last_date']) . '.';
    }
    $html .= '</p>';

    $bits = [];
    if (!empty($facts['total_vacancy']) && !is_placeholder($facts['total_vacancy']))
        $bits[] = 'Total vacancies: ' . htmlspecialchars($facts['total_vacancy']) . '.';
    if (!empty($facts['qualification'])) $bits[] = 'Qualification: ' . htmlspecialchars($facts['qualification']) . '.';
    if (!empty($facts['age_limit'])) $bits[] = 'Age limit: ' . htmlspecialchars($facts['age_limit']) . '.';
    if (!empty($facts['fee'])) $bits[] = 'Application fee: ' . htmlspecialchars($facts['fee']) . '.';
    if ($bits) $html .= '<p>' . implode(' ', $bits) . '</p>';

    if (!empty($facts['physical_eligibility'])) {
        $html .= '<h3>Physical Eligibility</h3><ul>';
        foreach ($facts['physical_eligibility'] as $item) $html .= '<li>' . htmlspecialchars($item) . '</li>';
        $html .= '</ul>';
    }

    if (!empty($facts['selection_process'])) {
        $html .= '<h3>Selection Process</h3><ul>';
        foreach ($facts['selection_process'] as $item) $html .= '<li>' . htmlspecialchars($item) . '</li>';
        $html .= '</ul>';
    }

    if (!empty($facts['important_dates_table']) && count($facts['important_dates_table']) >= 2) {
        $html .= '<h3>Schedule</h3><table>';
        foreach ($facts['important_dates_table'] as $row) {
            $html .= '<tr>' . implode('', array_map(fn($c) => '<td>' . htmlspecialchars($c) . '</td>', array_slice($row, 0, 2))) . '</tr>';
        }
        $html .= '</table>';
    }

    if (!empty($facts['salary_table']) && count($facts['salary_table']) >= 2) {
        $html .= '<h3>Salary</h3><table>';
        foreach ($facts['salary_table'] as $row) {
            $html .= '<tr>' . implode('', array_map(fn($c) => '<td>' . htmlspecialchars($c) . '</td>', $row)) . '</tr>';
        }
        $html .= '</table>';
    }

    $html .= '<p>See the official notification and apply link on this page for full details.</p>';
    return $html;
}

/**
 * Try Mistral, then Gemini, then the template. Returns [html, method].
 * Pass $skipAi=true to go straight to the free template without calling
 * either provider at all — used by `fetch_jobs.php --dry-run`, so testing
 * extraction against a source doesn't spend AI quota on every attempt.
 */
function generate_article(array $facts, bool $skipAi = false): array {
    if ($skipAi) {
        return ['body' => write_article_template($facts), 'method' => 'template (dry-run, AI skipped)'];
    }

    $factsText = build_facts_prompt($facts);

    $html = call_mistral($factsText);
    if ($html) return ['body' => $html, 'method' => 'mistral'];

    $html = call_gemini($factsText);
    if ($html) return ['body' => $html, 'method' => 'gemini'];

    return ['body' => write_article_template($facts), 'method' => 'template'];
}

/**
 * Small cURL POST helper shared by both providers. Returns response body or
 * null on any failure. Pass a variable by reference as $outCode to read back
 * the HTTP status code (e.g. to detect 429 rate-limit responses).
 */
function http_post_json(string $url, array $payload, array $extraHeaders, ?int &$outCode = null): ?string {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT        => 25,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_HTTPHEADER     => array_merge(['Content-Type: application/json'], $extraHeaders),
        CURLOPT_POSTFIELDS     => json_encode($payload),
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    $outCode = $code;
    if ($err || $code < 200 || $code >= 300) {
        error_log("AI writer HTTP $code for $url: " . ($err ?: substr((string)$body, 0, 300)));
        return null;
    }
    return $body;
}
