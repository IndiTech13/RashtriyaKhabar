#!/bin/bash
# Rashtriya Khabar — Govt Jobs one-shot deploy
# Run from inside the extracted govtjobs-deploy/ folder, as root/sudo, on
# the live server. Safe to re-run — every step is idempotent.
set -e

DOCROOT="/var/www/rashtriyakhabar"
CONF_DIR="/etc/govtjobs"
NGINX_CONF="/etc/nginx/conf.d/rashtriyakhabar.conf"

echo "== 1/8  Installing PHP-FPM + MySQL (skipped if already present) =="
dnf install -y -q php-fpm php-cli php-mysqlnd php-mbstring php-gd php-xml php-curl php-opcache mysql-server policycoreutils-python-utils >/dev/null

echo "== 2/8  Configuring PHP-FPM for Nginx + this VM's RAM =="
sed -i 's/^user = apache/user = nginx/; s/^group = apache/group = nginx/' /etc/php-fpm.d/www.conf
sed -i 's/^pm.max_children.*/pm.max_children = 5/' /etc/php-fpm.d/www.conf
sed -i 's/^pm = .*/pm = ondemand/' /etc/php-fpm.d/www.conf
systemctl enable --now php-fpm mysqld >/dev/null
systemctl restart php-fpm

mkdir -p /etc/my.cnf.d
if [ ! -f /etc/my.cnf.d/low-memory.cnf ]; then
  printf '[mysqld]\ninnodb_buffer_pool_size = 128M\nmax_connections = 30\n' > /etc/my.cnf.d/low-memory.cnf
  systemctl restart mysqld
fi

echo "== 3/8  Creating the database (auto-generated password) =="
DB_PASS=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 24)
mysql -u root <<SQL
CREATE DATABASE IF NOT EXISTS govtjobs CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'govtjobs_app'@'localhost' IDENTIFIED BY '${DB_PASS}';
ALTER USER 'govtjobs_app'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON govtjobs.* TO 'govtjobs_app'@'localhost';
DROP USER IF EXISTS ''@'localhost';
DROP DATABASE IF EXISTS test;
FLUSH PRIVILEGES;
SQL
mysql -u govtjobs_app -p"${DB_PASS}" govtjobs < db/schema.sql

echo "== 4/8  Installing config outside the docroot =="
mkdir -p "$CONF_DIR"
cp etc-govtjobs/*.php "$CONF_DIR"/
sed -i "s/^define('DB_PASS', '.*');/define('DB_PASS', '${DB_PASS}');/" "$CONF_DIR/config.php"

echo "== 5/8  Copying site files =="
cp -r webroot/* "$DOCROOT"/
cp create_admin.php fetch_jobs.php /root/

echo "== 6/8  Updating Nginx (tested before reload — your live site is not touched if this fails) =="
[ -f "$NGINX_CONF" ] && cp "$NGINX_CONF" "${NGINX_CONF}.bak.$(date +%s)"
cp nginx-rashtriyakhabar.conf "$NGINX_CONF"
if nginx -t; then
  systemctl reload nginx
else
  echo "!! nginx -t FAILED — restoring your previous config, nothing changed on the live site."
  LATEST_BAK=$(ls -t "${NGINX_CONF}".bak.* 2>/dev/null | head -1)
  [ -n "$LATEST_BAK" ] && cp "$LATEST_BAK" "$NGINX_CONF"
  exit 1
fi

echo "== 7/8  SELinux =="
mkdir -p "$CONF_DIR/sessions"
chown -R nginx:nginx "$DOCROOT/uploads" "$CONF_DIR"
chmod 640 "$CONF_DIR"/*.php
setsebool -P httpd_can_network_connect_db 1
semanage fcontext -a -t httpd_sys_rw_content_t "$DOCROOT/uploads(/.*)?" 2>/dev/null || true
semanage fcontext -a -t httpd_sys_rw_content_t "$CONF_DIR/sessions(/.*)?" 2>/dev/null || true
restorecon -Rv "$DOCROOT/uploads" "$CONF_DIR/sessions" >/dev/null

echo "== 8/8  Done =="
echo
echo "Database password (saved into $CONF_DIR/config.php already): $DB_PASS"
echo "Test:  curl -I https://rashtriyakhabar.in/jobs"
echo
echo "Last step — create your panel login (you'll be asked to type a password):"
echo "  cd /root && php create_admin.php youradminname"
